package com.example.ttap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TtapApplicationTests {

    @Test
    void contextLoads() {
    }

}
