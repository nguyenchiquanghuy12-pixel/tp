package com.example.ttap.repository;
import com.example.ttap.entity.Order;
import com.example.ttap.entity.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
@Repository
public interface orderre extends JpaRepository<Order, Integer> {
    List<Order> findByNguoidungIdOrderByIdDesc(Integer nguoidungId);
    List<Order> findAllByOrderByIdDesc();
    List<Order> findByNguoidungId(Integer nguoidungId);
    long count();

    // Đếm số lượng đơn theo từng OrderStatus
    long countByStatus(OrderStatus status);

    // Tổng doanh thu các đơn đã giao thành công (DELIVERED)
    @Query("SELECT COALESCE(SUM(o.totalAmount), 0) FROM Order o WHERE o.status = :status")
    BigDecimal sumTotalAmountByStatus(@Param("status") OrderStatus status);

    // Hoặc tổng doanh thu loại trừ đơn hủy / hoàn tiền nếu bạn tính sớm hơn:
    @Query("SELECT COALESCE(SUM(o.totalAmount), 0) FROM Order o WHERE o.status NOT IN ('CANCELLED', 'REFUNDED')")
    BigDecimal sumValidRevenue();
}