package com.example.ttap.service;

import com.example.ttap.entity.ShippingRegion;
import org.springframework.stereotype.Service;

@Service
public class ShippingService {
    private static final double FREESHIP_THRESHOLD = 500000.0;

    /**
     * Tính phí vận chuyển dựa trên tổng tiền hàng và khu vực giao hàng
     */
    public double calculateShippingFee(double subtotal, ShippingRegion region) {
        // Rule 1: Miễn phí vận chuyển khi tổng tiền đơn hàng đạt ngưỡng
        if (subtotal >= FREESHIP_THRESHOLD) {
            return 0.0;
        }

        // Rule 2: Phí theo khu vực (Nếu chưa chọn khu vực thì lấy mặc định Ngoại thành 30k)
        if (region != null) {
            return region.getBaseFee();
        }

        return ShippingRegion.OUTER_CITY.getBaseFee();
    }

    public double getFreeshipThreshold() {
        return FREESHIP_THRESHOLD;
    }
}
