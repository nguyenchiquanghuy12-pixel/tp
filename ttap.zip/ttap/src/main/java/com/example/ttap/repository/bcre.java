package com.example.ttap.repository;

import com.example.ttap.entity.baocao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface bcre extends JpaRepository<baocao, Integer> {
}
