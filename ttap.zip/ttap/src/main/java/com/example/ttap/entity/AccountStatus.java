package com.example.ttap.entity;

public enum AccountStatus {
    ACTIVE("Hoạt động"),
    INACTIVE("Chẳng hoạt động"),
    DELETED("Bị xóa");

    private final String label;

    AccountStatus(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}