package com.example.ttap.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class MockPaymentGatewayService {

    // Cấu hình trong application.properties: app.payment.mock.mode=AUTO | ALWAYS_SUCCESS | ALWAYS_FAILED
    @Value("${app.payment.mock.mode:AUTO}")
    private String defaultMode;

    // Tỷ lệ thành công khi mode = AUTO (0.0 -> 1.0)
    @Value("${app.payment.mock.success-rate:0.7}")
    private double successRate;

    public GatewaySimulationResult processPayment(Integer orderId, Double amount, String requestedOutcome) {
        String effectiveMode = (requestedOutcome != null && !requestedOutcome.isBlank())
                ? requestedOutcome.trim().toUpperCase()
                : defaultMode.trim().toUpperCase();

        boolean isSuccess = switch (effectiveMode) {
            case "SUCCESS", "ALWAYS_SUCCESS" -> true;
            case "FAILED", "ALWAYS_FAILED" -> false;
            default -> ThreadLocalRandom.current().nextDouble() < successRate;
        };

        String txnRef = "MOCK_TXN_" + orderId + "_" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        if (isSuccess) {
            return new GatewaySimulationResult(true, txnRef, null);
        }
        return new GatewaySimulationResult(
                false,
                txnRef,
                "Gateway mô phỏng từ chối giao dịch (số tiền: " + amount + "). Vui lòng thử lại."
        );
    }
}