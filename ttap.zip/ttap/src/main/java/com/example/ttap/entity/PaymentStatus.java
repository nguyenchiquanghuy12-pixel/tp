package com.example.ttap.entity;

public enum PaymentStatus {

    INITIATED("Đã khởi tạo"),
    SUCCESS("Thành công"),
    FAILED("Thất bại"),
    REFUNDED("Đã hoàn tiền");

    private final String description;

    PaymentStatus(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }}
