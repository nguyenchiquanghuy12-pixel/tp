package com.example.ttap.service;

import com.example.ttap.entity.sanpham;
import com.example.ttap.repository.CartItemRepository;
import com.example.ttap.repository.OItemRepository;
import com.example.ttap.repository.sphamre;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class SanphamService {

    @Autowired
    private sphamre sanphamRepository;
    @Autowired
    OItemRepository oItemRepository;
    /**
     * Lấy toàn bộ danh sách sản phẩm có trong cửa hàng
     */
    @Autowired
    CartItemRepository cartItemRepository;
    @Cacheable(value = "productsList")
    public List<sanpham> getAllProduct() {
        return sanphamRepository.findAll();
    }
    @Cacheable(value = "productsPage", key = "#pageable.pageNumber + '-' + #pageable.pageSize")
    public Page<sanpham> getAllProducts(Pageable pageable) {
        return sanphamRepository.findAll(pageable);
    }

    /**
     * Tìm kiếm sản phẩm theo ID (Dùng cho trang chi tiết, giỏ hàng, đặt hàng, review)
     * Sẽ ném ra ngoại lệ nếu không tìm thấy sản phẩm.
     */
    @Transactional(readOnly = true)
    @Cacheable(value = "productDetail", key = "#id")
    public sanpham findById(Integer id) {
        return sanphamRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy sản phẩm với ID: " + id));
    }

    /**
     * Lưu mới hoặc cập nhật thông tin sản phẩm (Dùng cho trang quản trị Admin)
     */
    @CacheEvict(value = {"productsList", "productDetail", "productsPage"}, allEntries = true)
    public sanpham saveProduct(sanpham product) {
        if (product.getStock() == null) {
            product.setStock(0);
        }
        if (product.getReserve() == null) {
            product.setReserve(0);
        }
        return sanphamRepository.save(product);
    }

    /**
     * Xóa sản phẩm theo ID
     */
    @CacheEvict(value = {"productsList", "productDetail", "productsPage"}, allEntries = true)
    public void deleteProduct(Integer id) {
        if (!sanphamRepository.existsById(id)) {
            throw new RuntimeException("Sản phẩm cần xóa không tồn tại!");
        }
        sanphamRepository.deleteById(id);
    }

    /**
     * Tìm kiếm sản phẩm theo tên (Phục vụ chức năng thanh tìm kiếm)
     */
    public List<sanpham> searchProductsByName(String keyword) {
        // Lưu ý: Bạn cần định nghĩa hàm findByTenContainingIgnoreCase trong SanphamRepository nếu muốn dùng tính năng này
        return sanphamRepository.findAll(); // Hoặc gọi repository tương ứng
    }
//    public Long calculateActualReserve(Integer productId) {
//        // Ép kiểu Integer sang Long để truyền vào repository nếu cần, hoặc giữ nguyên nếu ID là Long
//        return oItemRepository.sumReservedQuantityByProduct(productId != null ? productId.longValue() : 0L);
//    }
public int calculateActualReserve(Integer productId) {
    // 1. Lấy tổng số lượng đang nằm trong các giỏ hàng
    Integer cartReserve = cartItemRepository.sumQuantityByProductId(productId);
    long cartCount = (cartReserve != null) ? cartReserve : 0L;

    // 2. Lấy tổng số lượng đang nằm trong các đơn hàng chưa giao/chưa hủy
    Long orderReserve = oItemRepository.sumReservedQuantityByOrder(productId);
    long orderCount = (orderReserve != null) ? orderReserve : 0L;

    // 3. Tổng số lượng đang giữ thực tế
    long totalReserve = cartCount + orderCount;

    return (int) totalReserve;
}
}