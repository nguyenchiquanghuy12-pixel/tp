package com.example.ttap.service;

import com.example.ttap.entity.danhmuc;
import com.example.ttap.repository.dmucre;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryService {
    @Autowired
    private dmucre categoryRepository;

    /**
     * Cache danh sách danh mục sản phẩm (Category List)
     */
    @Cacheable(value = "categoriesList")
    public List<danhmuc> getAllCategories() {
        return categoryRepository.findAll();
    }

    @CacheEvict(value = "categoriesList", allEntries = true)
    public danhmuc saveCategory(danhmuc category) {
        return categoryRepository.save(category);
    }
    @CacheEvict(value = {"categoriesList", "productsList", "productsPage"}, allEntries = true)
    public void deleteCategory(Integer id) {
        if (!categoryRepository.existsById(id)) {
            throw new RuntimeException("Danh mục cần xóa không tồn tại hoặc đã bị xóa!");
        }

        // Tiến hành xóa danh mục trong Database
        categoryRepository.deleteById(id);
    }
    @Cacheable(value = "categoryDetail", key = "#id")
    public danhmuc findById(Integer id) {
        return categoryRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy danh mục với ID: " + id));
    }
}
