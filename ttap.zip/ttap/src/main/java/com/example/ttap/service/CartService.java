//package com.example.ttap.service;
//
//import com.example.ttap.entity.Cart;
//import com.example.ttap.entity.CartItem;
//import com.example.ttap.entity.nguoidung;
//import com.example.ttap.entity.sanpham;
//import com.example.ttap.repository.CartItemRepository;
//import com.example.ttap.repository.CartRepository;
//import com.example.ttap.repository.ndre;
//import com.example.ttap.repository.sphamre;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.cache.annotation.CacheEvict;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//@Service
//public class CartService {
//
//    @Autowired
//    private CartRepository cartRepository;
//
//    @Autowired
//    private CartItemRepository cartItemRepository;
//
//    @Autowired
//    private sphamre sanphamRepository;
//
//    @Autowired
//    private ndre nguoiDungRepository;
//
//    @Autowired
//    private org.springframework.cache.CacheManager cacheManager;
//    // Lấy hoặc tự động tạo giỏ hàng cho Customer nếu chưa có
//    public Cart getOrCreateCart(nguoidung customer) {
//        return cartRepository.findByNguoidungId(customer.getId())
//                .orElseGet(() -> {
//                    Cart newCart = new Cart();
//                    newCart.setNguoidung(customer);
//                    return cartRepository.save(newCart);
//                });
//    }
//
//    // Lấy giỏ hàng theo userId (Hỗ trợ tìm kiếm trực tiếp qua ID)
//    @Transactional
//    public Cart getCartByUserId(Integer userId) {
//        return cartRepository.findByNguoidungId(userId)
//                .orElseGet(() -> {
//                    nguoidung user = nguoiDungRepository.findById(userId)
//                            .orElseThrow(() -> new RuntimeException("Không tìm thấy người dùng với ID: " + userId));
//
//                    Cart newCart = new Cart();
//                    newCart.setNguoidung(user);
//                    return cartRepository.save(newCart);
//                });
//    }
//
//    // 1. Thêm sản phẩm vào giỏ hàng (Có kiểm tra tồn kho & cập nhật reservedStock)
//    @Transactional
////    @CacheEvict(value = "productDetail", key = "#productId")
//    @CacheEvict(value = "productDetail", allEntries = true)
//    public void addProductToCart(nguoidung customer, Integer productId, int quantity) {
//        if (quantity <= 0) {
//            throw new RuntimeException("Số lượng thêm vào giỏ hàng phải lớn hơn 0!");
//        }
//
//        Cart cart = getOrCreateCart(customer);
//        sanpham product = sanphamRepository.findById(productId)
//                .orElseThrow(() -> new RuntimeException("Sản phẩm không tồn tại!"));
//
//        // Kiểm tra tồn kho khả dụng (Tổng tồn - Đang giữ hiện tại)
//        int totalStock = product.getStock() != null ? product.getStock() : 0;
//        int currentReserved = product.getReserve() != null ? product.getReserve() : 0;
//        int availableStock = totalStock - currentReserved;
//
//        // Kiểm tra xem sản phẩm đã có trong giỏ chưa để tính toán đúng lượng tăng thêm
//        CartItem existingItem = cartItemRepository.findByCartIdAndSanphamId(cart.getId(), productId).orElse(null);
//        int quantityToAdd = quantity;
//
//        if (existingItem != null) {
//            quantityToAdd = quantity; // Thêm số lượng mới cộng dồn
//        }
//
//        if (availableStock < quantityToAdd) {
//            throw new RuntimeException("Sản phẩm không đủ số lượng trong kho để giữ chỗ! (Còn lại: " + availableStock + ")");
//        }
//
//        // Cập nhật số lượng Đang giữ (Reserve) của sản phẩm
//        product.setReserve(currentReserved + quantityToAdd);
//        sanphamRepository.save(product);
//
//        if (existingItem != null) {
//            // Đã có -> Cộng dồn số lượng trong giỏ
//            existingItem.setQuantity(existingItem.getQuantity() + quantity);
//            cartItemRepository.save(existingItem);
//        } else {
//            // Chưa có -> Tạo mới CartItem
//            CartItem newItem = new CartItem();
//            newItem.setCart(cart);
//            newItem.setSanpham(product);
//            newItem.setQuantity(quantity);
//            cartItemRepository.save(newItem);
//        }
//    }
//
////     2. Thay đổi số lượng của 1 item cụ thể trong giỏ hàng
//    @Transactional
//    @CacheEvict(value = "productDetail", allEntries = true)
//    public void updateItemQuantity(Integer cartItemId, int newQuantity) {
//        CartItem item = cartItemRepository.findById(cartItemId)
//                .orElseThrow(() -> new RuntimeException("Không tìm thấy sản phẩm trong giỏ hàng!"));
//
//        sanpham product = item.getSanpham();
//        int oldQuantity = item.getQuantity();
//
//        if (newQuantity <= 0) {
//            // Nếu số lượng mới <= 0 -> Xóa item khỏi giỏ và hoàn lại toàn bộ số lượng giữ chỗ
//            int currentReserved = product.getReserve() != null ? product.getReserve() : 0;
//            product.setReserve(Math.max(0, currentReserved - oldQuantity));
//            sanphamRepository.save(product);
//
//            cartItemRepository.deleteById(cartItemId);
//            return;
//        }
//
//        // Tính chênh lệch số lượng để cập nhật reservedStock
//        int diff = newQuantity - oldQuantity; // Dương nếu tăng, Âm nếu giảm
//        if (diff > 0) {
//            // Kiểm tra xem kho có đủ đáp ứng phần tăng thêm không
//            int totalStock = product.getStock() != null ? product.getStock() : 0;
//            int currentReserved = product.getReserve() != null ? product.getReserve() : 0;
//            int availableStock = totalStock - currentReserved;
//
//            if (availableStock < 1) {
//                throw new RuntimeException("Kho không đủ hàng để tăng thêm số lượng này!");
//            }
//            product.setReserve(currentReserved + diff);
//        } else if (diff < 0) {
//            // Giảm số lượng -> Trả lại bớt phần chênh lệch vào kho
//            int currentReserved = product.getReserve() != null ? product.getReserve() : 0;
//            product.setReserve(Math.max(0, currentReserved + diff)); // diff đang âm nên cộng dồn sẽ giảm đi
//        }
//
//        sanphamRepository.save(product);
//
//        // Cập nhật số lượng mới cho CartItem
//        item.setQuantity(newQuantity);
//        cartItemRepository.save(item);
//    }
//    // 3. Xóa một sản phẩm khỏi giỏ hàng (Trả lại toàn bộ số lượng đang giữ về kho)
//    @Transactional
//    @CacheEvict(value = "productDetail", allEntries = true)
//    public void removeCartItem(Integer cartItemId) {
//        CartItem item = cartItemRepository.findById(cartItemId)
//                .orElseThrow(() -> new RuntimeException("Không tìm thấy sản phẩm trong giỏ hàng!"));
//
//        sanpham product = item.getSanpham();
//        int itemQuantity = item.getQuantity();
//
//        // Hoàn trả số lượng đang giữ về kho
//        int currentReserved = product.getReserve() != null ? product.getReserve() : 0;
//        product.setReserve(Math.max(0, currentReserved - itemQuantity));
//        sanphamRepository.save(product);
//
//        cartItemRepository.deleteById(cartItemId);
//    }
//
//    // 4. Làm trống giỏ hàng (Clear Cart) - Trả lại toàn bộ lượng giữ chỗ của tất cả sản phẩm trong giỏ
//    @Transactional
//    @CacheEvict(value = "productDetail", allEntries = true)
//    public void clearCart(nguoidung customer) {
//        Cart cart = getOrCreateCart(customer);
//
//        if (cart.getItems() != null && !cart.getItems().isEmpty()) {
//            for (CartItem item : cart.getItems()) {
//                sanpham product = item.getSanpham();
//                if (product != null) {
//                    int currentReserved = product.getReserve() != null ? product.getReserve() : 0;
//                    product.setReserve(Math.max(0, currentReserved - item.getQuantity()));
//                    sanphamRepository.save(product);
//                }
//            }
//        }
//
//        cart.getItems().clear();
//        cartRepository.save(cart);
//    }
//    public double calculateSubtotal(Cart cart) {
//        double subtotal = 0.0;
//        if (cart != null && cart.getItems() != null) {
//            for (CartItem item : cart.getItems()) {
//                if (item.getSanpham() != null) {
//                    double price = item.getSanpham().getGia();
//                    int quantity = item.getQuantity();
//                    subtotal += (price * quantity);
//                }
//            }
//        }
//        return subtotal;
//    }
//}
package com.example.ttap.service;

import com.example.ttap.entity.Cart;
import com.example.ttap.entity.CartItem;
import com.example.ttap.entity.nguoidung;
import com.example.ttap.entity.sanpham;
import com.example.ttap.repository.CartItemRepository;
import com.example.ttap.repository.CartRepository;
import com.example.ttap.repository.ndre;
import com.example.ttap.repository.sphamre;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private sphamre sanphamRepository;

    @Autowired
    private ndre nguoiDungRepository;

    @Autowired
    private org.springframework.cache.CacheManager cacheManager;

    public Cart getOrCreateCart(nguoidung customer) {
        return cartRepository.findByNguoidungId(customer.getId())
                .orElseGet(() -> {
                    Cart newCart = new Cart();
                    newCart.setNguoidung(customer);
                    return cartRepository.save(newCart);
                });
    }

    @Transactional
    public Cart getCartByUserId(Integer userId) {
        return cartRepository.findByNguoidungId(userId)
                .orElseGet(() -> {
                    nguoidung user = nguoiDungRepository.findById(userId)
                            .orElseThrow(() -> new RuntimeException("Không tìm thấy người dùng với ID: " + userId));

                    Cart newCart = new Cart();
                    newCart.setNguoidung(user);
                    return cartRepository.save(newCart);
                });
    }

    private int getAvailableStock(sanpham product) {
        int totalStock = product.getStock() != null ? product.getStock() : 0;
        int reserved = product.getReserve() != null ? product.getReserve() : 0;
        return Math.max(0, totalStock - reserved);
    }

    // 1. Thêm vào giỏ hàng: chỉ cho phép khi tồn kho khả dụng >= quantity
    @Transactional
    @CacheEvict(value = "productDetail", allEntries = true)
    public void addProductToCart(nguoidung customer, Integer productId, int quantity) {
        if (quantity <= 0) {
            throw new RuntimeException("Số lượng thêm vào giỏ hàng phải lớn hơn 0!");
        }

        Cart cart = getOrCreateCart(customer);
        sanpham product = sanphamRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Sản phẩm không tồn tại!"));

        int availableStock = getAvailableStock(product);
        if (availableStock < quantity) {
            throw new RuntimeException(
                    "Tình trạng kho không đủ! Chỉ còn " + availableStock + " sản phẩm khả dụng."
            );
        }

        int currentReserved = product.getReserve() != null ? product.getReserve() : 0;
        product.setReserve(currentReserved + quantity);
        sanphamRepository.saveAndFlush(product);

        CartItem existingItem = cartItemRepository.findByCartIdAndSanphamId(cart.getId(), productId).orElse(null);
        if (existingItem != null) {
            existingItem.setQuantity(existingItem.getQuantity() + quantity);
            cartItemRepository.saveAndFlush(existingItem);
        } else {
            CartItem newItem = new CartItem();
            newItem.setCart(cart);
            newItem.setSanpham(product);
            newItem.setQuantity(quantity);
            cartItemRepository.saveAndFlush(newItem);
        }
    }

    // 2. Cập nhật số lượng item trong giỏ: chỉ cho tăng thêm khi availableStock >= (newQuantity - oldQuantity)
    @Transactional
    @CacheEvict(value = "productDetail", allEntries = true)
    public void updateItemQuantity(Integer cartItemId, int newQuantity) {
        CartItem item = cartItemRepository.findById(cartItemId)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy sản phẩm trong giỏ hàng!"));

        sanpham product = sanphamRepository.findById(item.getSanpham().getId())
                .orElseThrow(() -> new RuntimeException("Sản phẩm không tồn tại!"));

        int oldQuantity = item.getQuantity();
        int currentReserved = product.getReserve() != null ? product.getReserve() : 0;

        if (newQuantity <= 0) {
            product.setReserve(Math.max(0, currentReserved - oldQuantity));
            sanphamRepository.saveAndFlush(product);
            cartItemRepository.deleteById(cartItemId);
            return;
        }

        int diff = newQuantity - oldQuantity;
        if (diff > 0) {
            int availableStock = getAvailableStock(product);
            if (availableStock < diff) {
                throw new RuntimeException(
                        "Tình trạng kho không đủ để tăng thêm!"
                );
            }
            product.setReserve(currentReserved + diff);
            sanphamRepository.saveAndFlush(product);
        } else if (diff < 0) {
            product.setReserve(Math.max(0, currentReserved + diff));
            sanphamRepository.saveAndFlush(product);
        }

        item.setQuantity(newQuantity);
        cartItemRepository.saveAndFlush(item);
    }

    // 3. Xóa 1 món khỏi giỏ hàng
    @Transactional
    @CacheEvict(value = "productDetail", allEntries = true)
    public void removeCartItem(Integer cartItemId) {
        CartItem item = cartItemRepository.findById(cartItemId)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy sản phẩm trong giỏ hàng!"));

        sanpham product = sanphamRepository.findById(item.getSanpham().getId())
                .orElseThrow(() -> new RuntimeException("Sản phẩm không tồn tại!"));

        int itemQuantity = item.getQuantity();
        int currentReserved = product.getReserve() != null ? product.getReserve() : 0;
        product.setReserve(Math.max(0, currentReserved - itemQuantity));
        sanphamRepository.saveAndFlush(product);

        cartItemRepository.deleteById(cartItemId);
    }

    // 4. Làm trống giỏ hàng
    @Transactional
    @CacheEvict(value = "productDetail", allEntries = true)
    public void clearCart(nguoidung customer) {
        Cart cart = getOrCreateCart(customer);

        if (cart.getItems() != null && !cart.getItems().isEmpty()) {
            for (CartItem item : cart.getItems()) {
                if (item.getSanpham() != null) {
                    sanpham product = sanphamRepository.findById(item.getSanpham().getId()).orElse(item.getSanpham());
                    int currentReserved = product.getReserve() != null ? product.getReserve() : 0;
                    product.setReserve(Math.max(0, currentReserved - item.getQuantity()));
                    sanphamRepository.saveAndFlush(product);
                }
            }
        }

        cart.getItems().clear();
        cartRepository.saveAndFlush(cart);
    }

    public double calculateSubtotal(Cart cart) {
        double subtotal = 0.0;
        if (cart != null && cart.getItems() != null) {
            for (CartItem item : cart.getItems()) {
                if (item.getSanpham() != null) {
                    double price = item.getSanpham().getGia();
                    int quantity = item.getQuantity();
                    subtotal += (price * quantity);
                }
            }
        }
        return subtotal;
    }
}