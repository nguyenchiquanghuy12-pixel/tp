package com.example.ttap.entity;

public enum OrderStatus {


    PENDING("Chờ thanh toán"),
    PAID("Đã thanh toán"),
    PROCESSING("Đang xử lý"),
    SHIPPING("Đang giao hàng"),
    DELIVERED("Đã giao hàng"),
    CANCELLED("Đã hủy"),
    REFUNDED("Đã hoàn tiền");

    private final String description;

    OrderStatus(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    // Kiểm tra xem trạng thái hiện tại có thể hủy hay không
    public boolean canCancel() {
        return this == PENDING || this == PAID || this == PROCESSING;
    }
    public boolean canTransitionTo(OrderStatus nextStatus) {
        if (this == nextStatus) return true; // Giữ nguyên trạng thái cũ thì luôn hợp lệ

        switch (this) {


                case PENDING:
                // Chờ thanh toán -> Có thể chuyển sang Đã thanh toán hoặc Bị hủy
                return nextStatus == PAID || nextStatus == CANCELLED;

            case PAID:
                // Đã thanh toán -> Có thể chuyển sang Đang xử lý, Bị hủy hoặc Hoàn tiền
                return nextStatus == PROCESSING || nextStatus == CANCELLED || nextStatus == REFUNDED;

            case PROCESSING:
                // Đang xử lý -> Có thể chuyển sang Đang giao, Bị hủy hoặc Hoàn tiền
                return nextStatus == SHIPPING || nextStatus == CANCELLED || nextStatus == REFUNDED;

            case SHIPPING:
                // Đang giao hàng -> Chỉ có thể sang Đã giao thành công
                return nextStatus == DELIVERED;

            case DELIVERED:
                // Đã giao hàng thành công -> Khóa các trạng thái khác, chỉ cho phép hoàn tiền nếu có sự cố
                return nextStatus == REFUNDED;

            case CANCELLED:
            case REFUNDED:
                // Đã hủy hoặc Đã hoàn tiền là trạng thái kết thúc, KHÔNG CHO PHÉP chuyển đi đâu nữa
                return false;

            default:
                return false;
        }
    }
}