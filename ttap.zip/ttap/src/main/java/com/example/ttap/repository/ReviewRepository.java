package com.example.ttap.repository;

import com.example.ttap.entity.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Integer> {
    // Lấy danh sách review của một sản phẩm
    List<Review> findBySanphamId(Integer sanphamId);

    // Kiểm tra xem khách hàng này đã đánh giá sản phẩm này chưa (nếu giới hạn 1 review/1 sản phẩm)
    boolean existsByNguoidungIdAndSanphamId(Integer nguoidungId, Integer sanphamId);
}