package com.example.ttap.service;

import com.example.ttap.entity.sanpham;
import com.example.ttap.repository.sphamre;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class InventoryService {
    @Autowired
    private sphamre sanphamRepository;

    /**
     * Giữ chỗ sản phẩm khi khách thêm vào giỏ hàng / đặt đơn
     */
    @Transactional
    public boolean reserveStock(Integer productId, int quantityToReserve) {
        sanpham sp = sanphamRepository.findById(productId).orElse(null);
        if (sp == null) return false;

        // Kiểm tra xem số lượng có thể bán có đủ đáp ứng không
        if (sp.getAvailableQuantity() < quantityToReserve) {
            throw new RuntimeException("Sản phẩm '" + sp.getTen() + "' không đủ số lượng tồn kho khả dụng!");
        }

        // Tăng số lượng đang reserve lên
        sp.setReserve(sp.getReserve() + quantityToReserve);
        sanphamRepository.save(sp);
        return true;
    }

    /**
     * Giải phóng số lượng reserve (khi khách hủy giỏ hàng hoặc hủy đơn)
     */
    @Transactional
    public void releaseStock(Integer productId, int quantityToRelease) {
        sanpham sp = sanphamRepository.findById(productId).orElse(null);
        if (sp != null) {
            int newReserved = sp.getReserve() - quantityToRelease;
            sp.setReserve(Math.max(newReserved, 0)); // Chặn không cho âm
            sanphamRepository.save(sp);
        }
    }

    /**
     * Xác nhận bán hàng (Trừ trực tiếp vào tổng stock và giảm reserved)
     */
    @Transactional
    public void confirmSale(Integer productId, int quantitySold) {
        sanpham sp = sanphamRepository.findById(productId).orElse(null);
        if (sp != null) {
            int newStock = sp.getStock() - quantitySold;
            int newReserved = sp.getReserve() - quantitySold;

            // Ép chặn không cho âm tuyệt đối
            sp.setStock(Math.max(newStock, 0));
            sp.setReserve(Math.max(newReserved, 0));

            sanphamRepository.save(sp);
        }
    }
}
