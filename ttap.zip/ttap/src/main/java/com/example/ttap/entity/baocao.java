package com.example.ttap.entity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "baocao")
public class baocao {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name = "danhgia")
    private String danhgia;
    @Column(name = "mota")
    private String mota;
    @ManyToOne
    @JoinColumn(name = "nbaocao", referencedColumnName = "email")
    private nguoidung nguoidung;
}
