package com.example.ttap.entity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDateTime;
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "coupons")
public class Coupon {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(unique = true, nullable = false, length = 50)
    private String code; // Mã code (Ví dụ: TTAP2026, GIAM50K)

    @Enumerated(EnumType.STRING)
    @Column(name = "discount_type", nullable = false)
    private DiscountType discountType; // PERCENTAGE hoặc FIXED

    @Column(name = "discount_value", nullable = false)
    private Double discountValue; // Giá trị giảm (Ví dụ: 10 cho 10%, hoặc 50000 cho 50k)

    @Column(name = "min_order_value")
    private Double minOrderValue; // Giá trị đơn hàng tối thiểu để áp dụng mã

    @Column(name = "max_discount_amount")
    private Double maxDiscountAmount;

    @Column(name = "start_date")
    private LocalDateTime startDate; // Thời gian bắt đầu hiệu lực

    @Column(name = "end_date")
    private LocalDateTime endDate; // Thời gian kết thúc hiệu lực

    @Column(name = "usage_limit")
    private Integer usageLimit; // Tổng số lượt sử dụng tối đa của mã

    @Column(name = "used_count")
    private Integer usedCount = 0; // Số lượt đã được sử dụng thực tế

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private CouponStatus status = CouponStatus.ACTIVE; // ACTIVE, EXPIRED, DISABLED

    @PrePersist
    protected void onCreate() {
        if (this.usedCount == null) {
            this.usedCount = 0;
        }
        if (this.status == null) {
            this.status = CouponStatus.ACTIVE;
        }
    }
}