package com.example.ttap.repository;

import com.example.ttap.entity.PaymentStatus;
import com.example.ttap.entity.payment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PaymentRepository extends JpaRepository<payment, Integer> {
    List<payment> findByOrderId(Integer orderId);

    // Tìm giao dịch thanh toán mới nhất của đơn hàng (hữu ích khi làm chức năng Retry)
    Optional<payment> findTopByOrderIdOrderByIdDesc(Integer orderId);
    boolean existsByOrderIdAndStatus(Integer orderId, PaymentStatus status);

    // Các phương thức hữu ích đi kèm cho lịch sử thanh toán / retry trên cùng Order
    List<payment> findByOrderIdOrderByCreatedAtDesc(Long orderId);

    boolean existsByOrderIdAndStatusIn(Long orderId, List<PaymentStatus> statuses);

    Optional<payment> findTopByOrderIdAndStatusOrderByCreatedAtDesc(Integer orderId, PaymentStatus status);

    Optional<payment> findTopByOrderIdOrderByCreatedAtDesc(Integer orderId);

    List<payment> findByOrderIdOrderByCreatedAtDesc(Integer orderId);
}
