package com.example.ttap.repository;

import com.example.ttap.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface dhre extends JpaRepository<Order, Integer> {
}
