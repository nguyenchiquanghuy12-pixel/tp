package com.example.ttap.service;

import com.example.ttap.entity.*;
import com.example.ttap.repository.orderre;
import com.example.ttap.repository.ReviewRepository;
import com.example.ttap.repository.sphamre;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ReviewService {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private orderre orderRepository;

    @Autowired
    private sphamre sanphamRepository;

    /**
     * Kiểm tra xem khách hàng đã mua sản phẩm này chưa dựa trên lịch sử đơn hàng
     */
    public boolean hasCustomerPurchasedProduct(Integer customerId, Integer productId) {
        List<Order> orders = orderRepository.findByNguoidungId(customerId);
        for (Order order : orders) {
            // Kiểm tra các đơn hàng đã thanh toán hoặc hoàn thành (ví dụ: PAID hoặc COMPLETED)
            if (order.getStatus() == OrderStatus.DELIVERED) {
                for (OItem item : order.getItems()) {
                    if (item.getSanpham().getId().equals(productId)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Thêm mới đánh giá
     */
    public void addReview(nguoidung customer, Integer productId, int rating, String comment) {
        // 1. Check rule đã mua hàng chưa
        if (!hasCustomerPurchasedProduct(customer.getId(), productId)) {
            throw new RuntimeException("Bạn chỉ có thể đánh giá sản phẩm sau khi đã mua và hoàn thành đơn hàng!");
        }

        // 2. Validate số sao (1-5)
        if (rating < 1 || rating > 5) {
            throw new RuntimeException("Số sao đánh giá phải từ 1 đến 5!");
        }

        sanpham product = sanphamRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Sản phẩm không tồn tại!"));

        Review review = new Review();
        review.setNguoidung(customer);
        review.setSanpham(product);
        review.setRating(rating);
        review.setComment(comment);
        review.setCreatedAt(LocalDateTime.now());

        reviewRepository.save(review);
    }

    /**
     * Sửa đánh giá (Rule: Đúng tác giả mới được sửa)
     */
    public void updateReview(Integer reviewId, nguoidung customer, int rating, String comment) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new RuntimeException("Đánh giá không tồn tại!"));

        if (!review.getNguoidung().getId().equals(customer.getId())) {
            throw new RuntimeException("Bạn không có quyền chỉnh sửa đánh giá này!");
        }

        review.setRating(rating);
        review.setComment(comment);
        review.setUpdatedAt(LocalDateTime.now());

        reviewRepository.save(review);
    }

    /**
     * Xóa đánh giá (Rule: Đúng tác giả hoặc Admin mới được xóa)
     */
    public void deleteReview(Integer reviewId, nguoidung customer) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new RuntimeException("Đánh giá không tồn tại!"));

        if (!review.getNguoidung().getId().equals(customer.getId())) {
            throw new RuntimeException("Bạn không có quyền xóa đánh giá này!");
        }

        reviewRepository.delete(review);
    }

    public List<Review> getReviewsByProduct(Integer productId) {
        return reviewRepository.findBySanphamId(productId);
    }
}