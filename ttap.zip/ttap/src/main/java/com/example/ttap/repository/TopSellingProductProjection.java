package com.example.ttap.repository; // hoặc package phù hợp

import java.math.BigDecimal;

public interface TopSellingProductProjection {
    Integer getProductId();
    String getProductName();
    Long getTotalSold();
    BigDecimal getTotalRevenue();
}