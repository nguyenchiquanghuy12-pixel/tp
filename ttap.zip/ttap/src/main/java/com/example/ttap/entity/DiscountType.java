package com.example.ttap.entity;

public enum DiscountType {
    PERCENTAGE, // Giảm theo phần trăm (%)
    FIXED
}
