package com.example.ttap.entity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDateTime;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "reviews")
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "nguoidung_id", nullable = false)
    private nguoidung nguoidung;

    @ManyToOne
    @JoinColumn(name = "sanpham_id", nullable = false)
    private sanpham sanpham;

    @Column(name = "rating", nullable = false)
    private int rating; // Từ 1 đến 5 sao

    @Column(name = "comment",nullable = false)
    private String comment; // Nội dung đánh giá

    @Column(name = "created_at")
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}