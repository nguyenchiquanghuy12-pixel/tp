package com.example.ttap.repository;

import com.example.ttap.entity.tonkho;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InventoryAuditRepository extends JpaRepository<tonkho,Integer> {
    List<tonkho> findAllByOrderByNgayThaoTacDesc();
}
