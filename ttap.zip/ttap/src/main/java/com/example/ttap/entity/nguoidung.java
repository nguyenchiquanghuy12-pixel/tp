package com.example.ttap.entity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "nguoidung")
public class nguoidung {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name = "email",nullable = false, unique = true)
    private String email;
    @Column(name = "pw",nullable = false)
    private String pw;
    @Column(name = "ten")
    private String ten;
    @Column(name = "sodt")
    private String sodt;
    @Column(name = "dc")
    private String dc;
    @Column(name = "vaitro")
    private Boolean vaitro = true;
//    @Column(name = "ti")
//    private Boolean ti;
@Enumerated(EnumType.STRING)
@Column(name = "ti", columnDefinition = "VARCHAR(20)")
private AccountStatus ti = AccountStatus.INACTIVE;
}
