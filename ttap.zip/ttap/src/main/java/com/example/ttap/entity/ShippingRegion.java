package com.example.ttap.entity;

public enum ShippingRegion {
    INNER_CITY("Nội thành (Hà Nội / TP.HCM)", 20000.0),
    OUTER_CITY("Ngoại thành", 30000.0),
    PROVINCE("Tỉnh / Thành phố khác", 45000.0);

    private final String description;
    private final double baseFee;

    ShippingRegion(String description, double baseFee) {
        this.description = description;
        this.baseFee = baseFee;
    }

    public String getDescription() { return description; }
    public double getBaseFee() { return baseFee; }
}
