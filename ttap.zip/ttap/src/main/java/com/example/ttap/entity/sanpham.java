package com.example.ttap.entity;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "sanpham")
public class sanpham {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name = "sku", unique = true)
    private String sku;
    @Column(name = "ten")
    private String ten;
    @Column(name = "description")
    private String description;
    @Column(name = "gia")
    private Integer gia;
    @Column(name = "anh")
    private String anh;
    @ManyToOne
    @JoinColumn(name = "danhmucid", referencedColumnName = "id")
    private danhmuc danhmuc;
    @Column(name = "ti")
    private Boolean ti;
    @Column(name = "stock")
    @Min(value = 0, message = "Số lượng tồn kho không được âm")
    private Integer stock; // Tổng số lượng hiện có trong kho
    @Column(name = "reserve")
    @Min(value = 0, message = "Số lượng giữ chỗ không được âm")
    private Integer reserve; // Số lượng đang bị giữ (trong giỏ hàng / đơn chờ xử lý)
    // Phương thức tính toán số lượng thực tế có thể bán (Không lưu vào DB để tránh lệch dữ liệu)
//    @Transient
//    public Integer getAvailableQuantity() {
//        int available = stock- reserve;
//        return Math.max(available, 0);
//    }
    @Transient
    public Integer getAvailableQuantity() {
        int currentStock = (stock != null) ? stock : 0;
        int currentReserve = (reserve != null) ? reserve : 0;
        int available = currentStock - currentReserve;
        return Math.max(available, 0);
    }
}
