package com.example.ttap.repository;

import com.example.ttap.entity.danhmuc;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Dictionary;

@Repository
public interface dmucre extends JpaRepository<danhmuc, Integer> {
    Dictionary<Object, Object> findByTen(String ten);

    danhmuc findByTi(Boolean ti);
}
