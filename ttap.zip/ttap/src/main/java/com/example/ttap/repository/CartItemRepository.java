package com.example.ttap.repository;

import com.example.ttap.entity.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CartItemRepository extends JpaRepository<CartItem, Integer> {
    Optional<CartItem> findByCartIdAndSanphamId(Integer cartId, Integer sanphamId);
    @Query("SELECT COALESCE(SUM(ci.quantity), 0) FROM CartItem ci WHERE ci.sanpham.id = :productId")
    Integer sumQuantityByProductId(@Param("productId") Integer productId);
}