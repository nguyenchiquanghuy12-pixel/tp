package com.example.ttap.entity;

public enum CouponStatus {
    ACTIVE,   // Đang hoạt động
    EXPIRED,  // Hết hạn
    DISABLED
}
