package com.example.ttap.repository; // Thay bằng package của bạn
import com.example.ttap.entity.OItem;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OItemRepository extends JpaRepository<OItem, Long> {
//    @Query("SELECT COALESCE(SUM(i.quantity), 0) FROM OItem i WHERE i.sanpham.id = :productId AND i.order.status NOT IN ('DELIVERED', 'CANCELLED')")
//    Long sumReservedQuantityByProduct(@Param("productId") Long productId);
@Query("SELECT COALESCE(SUM(i.quantity), 0) FROM OItem i WHERE i.sanpham.id = :productId AND i.order.status NOT IN ('DELIVERED', 'CANCELLED')")
Long sumReservedQuantityByOrder(@Param("productId") Integer productId);
//    @Query("""
//        SELECT i.sanpham.id AS productId,
//               i.sanpham.ten AS productName,
//               COALESCE(SUM(i.quantity), 0) AS totalSold,
//               COALESCE(SUM(i.quantity * i.unitPrice), 0) AS totalRevenue
//        FROM OItem i
//        WHERE i.order.status = com.example.ttap.entity.OrderStatus.DELIVERED
//        GROUP BY i.sanpham.id, i.sanpham.ten
//        ORDER BY totalSold DESC
//    """)
@Query(value = """
    SELECT sp.id AS productId,
           sp.ten AS productName,
           COALESCE(SUM(oi.quantity), 0) AS totalSold,
           COALESCE(SUM(
               CASE
                   WHEN sub.raw_total > 0
                   THEN (CAST(oi.quantity AS FLOAT) * CAST(oi.unit_price AS FLOAT))
                        * (CAST(o.total_amount AS FLOAT) / CAST(sub.raw_total AS FLOAT))
                   ELSE (CAST(oi.quantity AS FLOAT) * CAST(oi.unit_price AS FLOAT))
               END
           ), 0) AS totalRevenue
    FROM order_item oi
    JOIN orders o ON oi.order_id = o.id
    JOIN sanpham sp ON oi.sanpham_id = sp.id
    OUTER APPLY (
        SELECT COALESCE(SUM(sub_oi.quantity * sub_oi.unit_price), 0) AS raw_total
        FROM order_item sub_oi
        WHERE sub_oi.order_id = oi.order_id
    ) sub
    WHERE o.status = 'DELIVERED'
    GROUP BY sp.id, sp.ten
    ORDER BY totalSold DESC
    """, nativeQuery = true)
    List<TopSellingProductProjection> findTopSellingProducts(Pageable pageable);
}