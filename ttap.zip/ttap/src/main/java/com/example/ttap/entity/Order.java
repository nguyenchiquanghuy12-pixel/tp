package com.example.ttap.entity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "nguoidung_id", nullable = false)
    private nguoidung nguoidung;

    @Column(name = "shipping_address", columnDefinition = "TEXT", nullable = false)
    private String shippingAddress; // Snapshot địa chỉ giao hàng

    @Column(nullable = false)
    private double subtotal;

    @Column(name = "discount_amount")
    private double discountAmount = 0.0;

    @Column(name = "shipping_fee")
    private double shippingFee = 0.0;

    @Column(name = "total_amount", nullable = false)
    private double totalAmount;

    @Column(name = "coupon_code")
    private String couponCode;

//    @Column(nullable = false)
//    private String status = "PENDING"; // PENDING, PROCESSING, COMPLETED, CANCELLED

    @Column(name = "created_at")
    private LocalDateTime createdAt = LocalDateTime.now();

    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<OItem> items = new ArrayList<>();
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 30)
    private OrderStatus status = OrderStatus.PENDING;
}
