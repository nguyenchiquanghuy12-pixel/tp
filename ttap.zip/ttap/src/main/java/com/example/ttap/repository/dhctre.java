package com.example.ttap.repository;

import com.example.ttap.entity.OItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface dhctre extends JpaRepository<OItem, Integer> {
}
