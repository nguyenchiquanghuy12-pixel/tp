package com.example.ttap.service;

import com.example.ttap.entity.AccountStatus;
import com.example.ttap.entity.nguoidung;
import com.example.ttap.repository.ndre;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Locale;

@Service
public class NguoidungAdminService {

    private final ndre nguoidungRepository;

    public NguoidungAdminService(ndre nguoidungRepository) {
        this.nguoidungRepository = nguoidungRepository;
    }

    public List<nguoidung> searchUsers(String keyword, String roleFilter) {
        String kw = (keyword == null) ? "" : keyword.trim().toLowerCase(Locale.ROOT);
        String role = (roleFilter == null) ? "ALL" : roleFilter.trim().toUpperCase(Locale.ROOT);

        return nguoidungRepository.findAllByOrderByIdDesc().stream()
                .filter(u -> {
                    if (kw.isEmpty()) return true;
                    String ten = safe(u.getTen()).toLowerCase(Locale.ROOT);
                    String email = safe(u.getEmail()).toLowerCase(Locale.ROOT);
                    String sodt = safe(u.getSodt()).toLowerCase(Locale.ROOT);
                    String dc = safe(u.getDc()).toLowerCase(Locale.ROOT);
                    return ten.contains(kw) || email.contains(kw) || sodt.contains(kw) || dc.contains(kw);
                })
                .filter(u -> {
                    if ("ALL".equals(role) || role.isEmpty()) return true;
                    boolean isUser = Boolean.TRUE.equals(u.getVaitro());
                    if ("USER".equals(role)) return isUser;
                    if ("ADMIN".equals(role)) return !isUser;
                    return true;
                })
                .toList();
    }

    public nguoidung findById(Integer id) {
        return nguoidungRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy người dùng #" + id));
    }

//    @Transactional
//    public void deleteUser(Integer targetUserId, Integer currentUserId) {
//        if (currentUserId != null && currentUserId.equals(targetUserId)) {
//            throw new IllegalStateException("Bạn không thể tự xóa tài khoản đang đăng nhập.");
//        }
//        findById(targetUserId);
//        nguoidungRepository.deleteById(targetUserId);
//    }
@Transactional
public void deleteUser(Integer targetUserId, Integer currentUserId) {
    if (currentUserId != null && currentUserId.equals(targetUserId)) {
        throw new IllegalStateException("Bạn không thể tự xóa tài khoản đang đăng nhập.");
    }
    nguoidung target = findById(targetUserId);
    if (target == null) {
        throw new IllegalArgumentException("Không tìm thấy người dùng #" + targetUserId);
    }
    target.setTi(AccountStatus.DELETED);
    nguoidungRepository.saveAndFlush(target);
}
    private String safe(String value) {
        return value == null ? "" : value;
    }
}