package com.example.ttap.service;

public record GatewaySimulationResult(
        boolean success,
        String transactionRef,
        String failureReason
) {}