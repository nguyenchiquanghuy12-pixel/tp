package com.example.ttap.repository;

import com.example.ttap.entity.sanpham;
import jakarta.persistence.LockModeType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface sphamre extends JpaRepository<sanpham, Integer> {
    @Query("SELECT s FROM sanpham s WHERE " +
            "LOWER(s.ten) LIKE LOWER(CONCAT('%', :kw, '%')) OR " +
            "LOWER(s.sku) LIKE LOWER(CONCAT('%', :kw, '%'))")
    Page<sanpham> searchProducts(@Param("kw") String keyword, Pageable pageable);
    Page<sanpham> findByTenContainingIgnoreCaseOrSkuContainingIgnoreCase(String ten, String sku, Pageable pageable);
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT s FROM sanpham s WHERE s.id = :id")
    Optional<sanpham> findByIdWithLock(@Param("id") Integer id);
}
