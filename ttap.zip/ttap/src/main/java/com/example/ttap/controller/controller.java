package com.example.ttap.controller;

import com.example.ttap.entity.*;
import com.example.ttap.repository.*;
import com.example.ttap.service.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/tt")
public class controller {

    @Autowired
    ndre nd;
    @Autowired
    dmucre dmucre;
    @Autowired
    sphamre sphamre;
    @Autowired
    InventoryAuditRepository auditRepository;
    @Autowired
    CartService cartService;
    @Autowired
    orderre orderRepository;
    @Autowired
    OrderService orderService;
    @Autowired
    CartRepository cartRepository;
    @Autowired
    CouponService couponService;
    @Autowired
    ShippingService shippingService;
    @Autowired
    SanphamService sanphamService;
    @Autowired
    ReviewService reviewService;
    @Autowired
    CategoryService categoryService;
    @Autowired
    CartItemRepository cartItemRepository;
    @Autowired
    AdminDashboardService adminDashboardService;
    @Autowired
    PaymentRepository paymentRepository;
    @Autowired
    NguoidungAdminService nguoidungAdminService;

    /**
     * Lấy người dùng hợp lệ mới nhất từ DB và hủy session nếu tài khoản đã bị xóa (DELETED).
     */
    private nguoidung resolveActiveUser(HttpSession session) {
        if (session == null) {
            return null;
        }
        nguoidung sessionUser = (nguoidung) session.getAttribute("loggedInUser");
        if (sessionUser == null) {
            sessionUser = (nguoidung) session.getAttribute("nguoidung");
        }
        if (sessionUser == null || sessionUser.getId() == null) {
            return null;
        }

        nguoidung freshUser = nd.findById(sessionUser.getId()).orElse(null);
        if (freshUser == null || freshUser.getTi() == AccountStatus.DELETED) {
            try {
                session.removeAttribute("nguoidung");
                session.removeAttribute("loggedInUser");
                session.invalidate();
            } catch (IllegalStateException ignored) {
                // Session đã bị hủy trước đó
            }
            return null;
        }

        session.setAttribute("nguoidung", freshUser);
        session.setAttribute("loggedInUser", freshUser);
        return freshUser;
    }

    @RequestMapping("/lamn")
    public String lamn(HttpSession session) {
        nguoidung ng = resolveActiveUser(session);
        if (ng != null) {
            if (Boolean.TRUE.equals(ng.getVaitro())) {
                return "redirect:/tt/custom";
            } else {
                return "redirect:/tt/admin";
            }
        } else {
            return "/ttap/lamn";
        }
    }

    @RequestMapping("/lamb")
    public String lamb(HttpSession session, Model model) {
        nguoidung ng = resolveActiveUser(session);
        if (ng != null) {
            if (Boolean.TRUE.equals(ng.getVaitro())) {
                return "redirect:/tt/custom";
            } else {
                return "redirect:/tt/admin";
            }
        } else {
            return "/ttap/lamb";
        }
    }

    @PostMapping("/themnd")
    public String themnd(HttpSession session, nguoidung ng, @RequestParam("email") String email, Model model) {
        if (nd.existsByEmail(email)) {
            model.addAttribute("error", "Email này đã được đăng ký!");
            return "/ttap/lamn";
        } else {
            ng.setTi(AccountStatus.ACTIVE);
            nguoidung savedUser = nd.saveAndFlush(ng);
            session.setAttribute("nguoidung", savedUser);
            session.setAttribute("loggedInUser", savedUser);
            return "redirect:/tt/tchu";
        }
    }

    @PostMapping("/pb")
    public String pb(@RequestParam("email") String email, @RequestParam("pw") String pw, HttpSession session, Model model) {
        nguoidung ng = nd.findByEmail(email);
        if (ng != null) {
            if (ng.getPw().equals(pw)) {
                if (ng.getTi() == AccountStatus.DELETED) {
                    model.addAttribute("error", "Tài khoản này đã bị xóa!");
                    return "redirect:/tt/lamb";
                } else {
                    ng.setTi(AccountStatus.ACTIVE);
                    nguoidung savedUser = nd.saveAndFlush(ng);
                    session.setAttribute("nguoidung", savedUser);
                    session.setAttribute("loggedInUser", savedUser);
                    if (Boolean.TRUE.equals(savedUser.getVaitro())) {
                        return "redirect:/tt/tchu";
                    } else {
                        return "redirect:/tt/admin";
                    }
                }
            } else {
                model.addAttribute("error", "Email hoặc mật khẩu không chính xác!");
                return "/ttap/lamb";
            }
        } else {
            return "redirect:/tt/lamb";
        }
    }

    @PostMapping("/cntn")
    public String cn(@ModelAttribute nguoidung form, HttpSession session, Model model) {
        nguoidung ng = resolveActiveUser(session);
        if (ng == null) {
            return "redirect:/tt/lamb";
        }
        ng.setTen(form.getTen());
        ng.setSodt(form.getSodt());
        ng.setDc(form.getDc());
        nguoidung updated = nd.saveAndFlush(ng);
        session.setAttribute("nguoidung", updated);
        session.setAttribute("loggedInUser", updated);
        model.addAttribute("nguoidung", updated);
        model.addAttribute("success", "Đổi thông tin xong!");
        return "/ttap/nd";
    }

    @PostMapping("/cnmm")
    public String cnmm(@RequestParam("mmc") String mmc, @RequestParam("mmm") String mmm, HttpSession session, Model model) {
        nguoidung ng = resolveActiveUser(session);
        if (ng == null) {
            return "redirect:/tt/lamb";
        }
        model.addAttribute("nguoidung", ng);
        if (ng.getPw().equals(mmc)) {
            ng.setPw(mmm);
            nguoidung updated = nd.saveAndFlush(ng);
            session.setAttribute("nguoidung", updated);
            session.setAttribute("loggedInUser", updated);
            model.addAttribute("success", "Đổi mật mã xong!");
            return "/ttap/nd";
        } else {
            model.addAttribute("error", "Mật mã cũ sai!");
            return "/ttap/nd";
        }
    }

    @RequestMapping("/custom")
    public String custom(HttpSession session) {
        nguoidung ng = resolveActiveUser(session);
        if (ng != null) {
            if (Boolean.TRUE.equals(ng.getVaitro())) {
                return "/ttap/custom";
            } else {
                return "redirect:/tt/admin";
            }
        } else {
            return "redirect:/tt/lamb";
        }
    }

    @RequestMapping("/admin")
    public String admin(HttpSession session, Model model) {
        nguoidung ng = resolveActiveUser(session);
        if (ng != null) {
            if (!Boolean.TRUE.equals(ng.getVaitro())) {
                model.addAttribute("danhmuc", categoryService.getAllCategories());
                model.addAttribute("spham", sanphamService.getAllProduct());
                return "/ttap/admin";
            } else {
                return "redirect:/tt/tchu";
            }
        } else {
            return "redirect:/tt/lamb";
        }
    }

    @RequestMapping("/nd")
    public String ndcuom(HttpSession session, Model model) {
        nguoidung ng = resolveActiveUser(session);
        model.addAttribute("nguoidung", ng);

        if (ng != null) {
            return "/ttap/nd";
        } else {
            return "redirect:/tt/lamb";
        }
    }

    @RequestMapping("/dx")
    public String dx(HttpSession session) {
        nguoidung ng = resolveActiveUser(session);
        if (ng != null && ng.getTi() != AccountStatus.DELETED) {
            ng.setTi(AccountStatus.INACTIVE);
            nd.saveAndFlush(ng);
        }
        try {
            session.removeAttribute("nguoidung");
            session.removeAttribute("loggedInUser");
            session.invalidate();
        } catch (IllegalStateException ignored) {
        }
        return "redirect:/tt/tchu";
    }

    @RequestMapping("/ndam")
    public String ndam(HttpSession session, Model model) {
        nguoidung ng = resolveActiveUser(session);
        model.addAttribute("nguoidung", ng);
        if (ng != null) {
            if (!Boolean.TRUE.equals(ng.getVaitro())) {
                return "/ttap/ndam";
            } else {
                return "redirect:/tt/custom";
            }
        } else {
            return "redirect:/tt/lamb";
        }
    }

    @PostMapping("/themdm")
    public String themdm(danhmuc dm) {
        categoryService.saveCategory(dm);
        return "redirect:/tt/admin";
    }

    @GetMapping("/xdm/{id}")
    public String xdm(@PathVariable("id") Integer id) {
        categoryService.deleteCategory(id);
        return "redirect:/tt/admin";
    }

//    @GetMapping("/sdm/{id}")
//    public String sdm(@PathVariable("id") Integer id, Model model) {
//        model.addAttribute("dm", categoryService.findById(id));
//        model.addAttribute("dmucre", categoryService.getAllCategories());
//        return "/ttap/andm";
//    }
//
//    @PostMapping("/suadm/{id}")
//    public String suadm(@PathVariable("id") Integer id, danhmuc dm) {
//        dm.setId(id);
//        categoryService.saveCategory(dm);
//        return "redirect:/tt/admin";
//    }
@GetMapping("/sdm/{id}")
public String sdm(@PathVariable("id") Integer id, HttpSession session, Model model, RedirectAttributes redirectAttributes) {
    nguoidung currentUser = resolveActiveUser(session);
    if (currentUser == null) {
        return "redirect:/tt/lamb";
    }
    if (Boolean.TRUE.equals(currentUser.getVaitro())) {
        return "redirect:/tt/tchu";
    }

    danhmuc dm = categoryService.findById(id);
    if (dm == null) {
        redirectAttributes.addFlashAttribute("error", "Không tìm thấy danh mục #" + id);
        return "redirect:/tt/admin";
    }

    model.addAttribute("dm", dm);
    model.addAttribute("dmucre", categoryService.getAllCategories());
    model.addAttribute("currentUser", currentUser);
    model.addAttribute("userEmail", currentUser.getEmail());
    return "/ttap/andm";
}

    @PostMapping("/suadm/{id}")
    public String suadm(@PathVariable("id") Integer id,
                        @ModelAttribute danhmuc dm,
                        HttpSession session,
                        Model model,
                        RedirectAttributes redirectAttributes) {
        nguoidung currentUser = resolveActiveUser(session);
        if (currentUser == null) {
            return "redirect:/tt/lamb";
        }
        if (Boolean.TRUE.equals(currentUser.getVaitro())) {
            return "redirect:/tt/tchu";
        }

        try {
            dm.setId(id);
            categoryService.saveCategory(dm);
            redirectAttributes.addFlashAttribute("success", "Cập nhật danh mục #" + id + " thành công!");
            return "redirect:/tt/admin";
        } catch (Exception e) {
            model.addAttribute("dm", dm);
            model.addAttribute("dmucre", categoryService.getAllCategories());
            model.addAttribute("currentUser", currentUser);
            model.addAttribute("userEmail", currentUser.getEmail());
            model.addAttribute("error", "Không thể cập nhật danh mục!");
            return "/ttap/andm";
        }
    }
    @PostMapping("/themsp")
    public String themsp(sanpham sp) {
        sanphamService.saveProduct(sp);

        return "redirect:/tt/admin";
    }
    @GetMapping("/xsp/{id}")
    public String xsp(@PathVariable("id") Integer id) {
        sanphamService.deleteProduct(id);
        return "redirect:/tt/admin";
    }

    @GetMapping("/ssp/{id}")
    public String ssp(@PathVariable("id") Integer id, Model model) {
        model.addAttribute("sp", sanphamService.findById(id));
        model.addAttribute("dmre", categoryService.getAllCategories());
        return "/ttap/ansp";
    }

    @PostMapping("/suasp/{id}")
    public String suasp(@PathVariable("id") Integer id, sanpham sp) {
        sp.setId(id);
        sanphamService.saveProduct(sp);
        return "redirect:/tt/admin";
    }

    @GetMapping("/tchu")
    public String trangChu(
            @RequestParam(name = "keyword", required = false, defaultValue = "") String keyword,
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "8") int size,
            HttpSession session,
            Model model) {

        nguoidung activeUser = resolveActiveUser(session);
        model.addAttribute("currentUser", activeUser);
        model.addAttribute("userEmail", activeUser != null ? activeUser.getEmail() : null);

        Pageable pageable = PageRequest.of(page, size);
        Page<sanpham> productPage;
        if (keyword != null && !keyword.trim().isEmpty()) {
            productPage = sphamre.searchProducts(keyword.trim(), pageable);
        } else {
            productPage = sanphamService.getAllProducts(pageable);
        }

        model.addAttribute("listsp", productPage.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", productPage.getTotalPages());
        model.addAttribute("keyword", keyword);

        return "/ttap/tchu";
    }

    @GetMapping("/xemsanpham/{id}")
    public String viewProductDetail(@PathVariable("id") Integer id, HttpSession session, Model model) {
        sanpham product = sphamre.findById(id)
                .orElseThrow(() -> new RuntimeException("Sản phẩm không tồn tại!"));

        int actualReserve = sanphamService.calculateActualReserve(product.getId());
        product.setReserve(actualReserve);

        model.addAttribute("sp", product);

        List<Review> reviews = reviewService.getReviewsByProduct(product.getId());
        model.addAttribute("reviews", reviews);

        nguoidung customer = resolveActiveUser(session);
        boolean hasPurchased = false;
        if (customer != null) {
            hasPurchased = reviewService.hasCustomerPurchasedProduct(customer.getId(), product.getId());
        }
        model.addAttribute("hasPurchased", hasPurchased);
        model.addAttribute("currentUser", customer);
        model.addAttribute("userEmail", customer != null ? customer.getEmail() : null);

        return "/ttap/xspham";
    }

    @RequestMapping("/sp")
    public String sp(@RequestParam(value = "keyword", required = false) String keyword,
                     @RequestParam(value = "page", defaultValue = "0") int page,
                     HttpSession session,
                     Model model) {
        nguoidung activeUser = resolveActiveUser(session);
        model.addAttribute("currentUser", activeUser);
        model.addAttribute("userEmail", activeUser != null ? activeUser.getEmail() : null);

        int pageSize = 36;
        Pageable pageable = PageRequest.of(page, pageSize);
        Page<sanpham> productPage;

        if (keyword != null && !keyword.trim().isEmpty()) {
            productPage = sphamre.findByTenContainingIgnoreCaseOrSkuContainingIgnoreCase(keyword, keyword, pageable);
        } else {
            productPage = sanphamService.getAllProducts(pageable);
        }

        model.addAttribute("listsp", productPage.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", productPage.getTotalPages());
        model.addAttribute("keyword", keyword);
        return "/ttap/spham";
    }

    @GetMapping("/tonkho")
    public String viewInventory(HttpSession session, Model model) {
        nguoidung activeUser = resolveActiveUser(session);
        model.addAttribute("currentUser", activeUser);
        model.addAttribute("userEmail", activeUser != null ? activeUser.getEmail() : null);

        List<sanpham> products = sphamre.findAll();

        for (sanpham p : products) {
            int actualReserve = sanphamService.calculateActualReserve(p.getId());
            p.setReserve(actualReserve);
        }

        model.addAttribute("spham", products);
        model.addAttribute("auditLogs", auditRepository.findAllByOrderByNgayThaoTacDesc());
        return "/ttap/tonkho";
    }

    @PostMapping("/tonkho/dieuchinh")
    public String adjustInventory(@RequestParam("sanPhamId") Integer sanPhamId,
                                  @RequestParam("loaiThaoTac") String loaiThaoTac,
                                  @RequestParam("soLuong") int soLuong,
                                  @RequestParam("ghiChu") String ghiChu,
                                  HttpSession session,
                                  RedirectAttributes redirectAttributes) {
        nguoidung currentUser = resolveActiveUser(session);
        if (currentUser == null || (currentUser.getVaitro() != null && currentUser.getVaitro())) {
            return "redirect:/tt/tchu";
        }

        sanpham sp = sphamre.findById(sanPhamId).orElse(null);
        if (sp != null) {
            int oldStock = sp.getStock();
            int delta = 0;

            if ("NHAP_THEM".equals(loaiThaoTac)) {
                delta = soLuong;
                sp.setStock(oldStock + soLuong);
            } else if ("XUAT_HUY".equals(loaiThaoTac)) {
                delta = -soLuong;
                sp.setStock(Math.max(0, oldStock - soLuong));
            } else if ("SET_MOI".equals(loaiThaoTac)) {
                delta = soLuong - oldStock;
                sp.setStock(soLuong);
            }

            sanphamService.saveProduct(sp);

            tonkho log = new tonkho();
            log.setSanphamSku(sp.getSku());
            log.setLoaiThaoTac(loaiThaoTac);
            log.setSoLuongThayDoi(delta);
            log.setAdminEmail(currentUser.getEmail());
            log.setGhiChu(ghiChu);
            log.setNgayThaoTac(LocalDateTime.now());
            auditRepository.save(log);

            redirectAttributes.addFlashAttribute("success", "Đã cập nhật tồn kho và ghi nhận lịch sử kiểm toán thành công!");
        } else {
            redirectAttributes.addFlashAttribute("error", "Không tìm thấy sản phẩm cần điều chỉnh!");
        }

        return "redirect:/tt/tonkho";
    }

    @GetMapping("/giohang")
    public String viewCart(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        nguoidung customer = resolveActiveUser(session);
        if (customer == null) {
            redirectAttributes.addFlashAttribute("error", "Vui lòng đăng nhập để xem giỏ hàng!");
            return "redirect:/tt/lamb";
        }

        Cart userCart = cartService.getCartByUserId(customer.getId());
        model.addAttribute("cart", userCart);
        model.addAttribute("currentUser", customer);
        model.addAttribute("userEmail", customer.getEmail());

        double tongTien = 0.0;
        if (userCart != null && userCart.getItems() != null) {
            tongTien = userCart.getItems().stream()
                    .mapToDouble(item -> item.getSanpham().getGia() * item.getQuantity())
                    .sum();
        }
        model.addAttribute("tongTien", tongTien);

        String appliedCouponCode = (String) session.getAttribute("APPLIED_CART_COUPON");
        double discountAmount = 0.0;

        if (appliedCouponCode != null && !appliedCouponCode.trim().isEmpty() && tongTien > 0) {
            try {
                discountAmount = couponService.previewDiscount(appliedCouponCode, tongTien);
                model.addAttribute("appliedCouponCode", appliedCouponCode);
                model.addAttribute("discountAmount", discountAmount);
            } catch (Exception e) {
                session.removeAttribute("APPLIED_CART_COUPON");
                model.addAttribute("error", e.getMessage());
            }
        }

        double shippingFee = shippingService.calculateShippingFee(tongTien, ShippingRegion.OUTER_CITY);

        double amountNeededForFreeship = shippingService.getFreeshipThreshold() - tongTien;
        if (amountNeededForFreeship < 0) {
            amountNeededForFreeship = 0;
        }

        double finalTotal = tongTien - discountAmount + shippingFee;
        if (finalTotal < 0) finalTotal = 0;

        model.addAttribute("shippingFee", shippingFee);
        model.addAttribute("amountNeededForFreeship", amountNeededForFreeship);
        model.addAttribute("freeshipThreshold", shippingService.getFreeshipThreshold());
        model.addAttribute("finalTotal", finalTotal);

        return "/ttap/gh";
    }

    @GetMapping("/giohang/them")
    public String addToCart(@RequestParam("productId") Integer productId,
                            @RequestParam(value = "quantity", defaultValue = "1") int quantity,
                            HttpSession session,
                            RedirectAttributes redirectAttributes) {

        nguoidung customer = resolveActiveUser(session);
        if (customer == null) {
            return "redirect:/tt/lamb";
        }

        try {
            cartService.addProductToCart(customer, productId, quantity);
            redirectAttributes.addFlashAttribute("success", "Đã thêm sản phẩm vào giỏ hàng thành công!");
        } catch (RuntimeException ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
            return "redirect:/tt/xemsanpham/" + productId;
        }

        return "redirect:/tt/giohang";
    }

    @PostMapping("/giohang/capnhat")
    public String updateQuantity(@RequestParam("cartItemId") Integer cartItemId,
                                 @RequestParam("quantity") int quantity,
                                 HttpSession session,
                                 RedirectAttributes redirectAttributes) {
        if (resolveActiveUser(session) == null) {
            return "redirect:/tt/lamb";
        }
        try {
            cartService.updateItemQuantity(cartItemId, quantity);
            redirectAttributes.addFlashAttribute("success", "Cập nhật số lượng thành công!");
        } catch (RuntimeException ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/tt/giohang";
    }

    @PostMapping("/giohang/xoa")
    public String removeFromCart(@RequestParam("cartItemId") Integer cartItemId,
                                 HttpSession session,
                                 RedirectAttributes redirectAttributes) {
        if (resolveActiveUser(session) == null) {
            return "redirect:/tt/lamb";
        }
        try {
            cartService.removeCartItem(cartItemId);
            redirectAttributes.addFlashAttribute("success", "Đã xóa sản phẩm khỏi giỏ hàng!");
        } catch (RuntimeException ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/tt/giohang";
    }

    @PostMapping("/giohang/xoatatca")
    public String clearCart(HttpSession session) {
        nguoidung currentUser = resolveActiveUser(session);
        if (currentUser != null) {
            cartService.clearCart(currentUser);
        }
        return "redirect:/tt/giohang";
    }

    @GetMapping("/checkout")
    public String viewCheckoutPage(HttpSession session, Model model) {
        nguoidung customer = resolveActiveUser(session);
        if (customer == null) {
            return "redirect:/tt/lamb";
        }
        model.addAttribute("customer", customer);
        model.addAttribute("currentUser", customer);
        model.addAttribute("userEmail", customer.getEmail());

        Cart cart = cartService.getCartByUserId(customer.getId());
        if (cart == null || cart.getItems() == null || cart.getItems().isEmpty()) {
            return "redirect:/tt/giohang";
        }
        model.addAttribute("cart", cart);

        double subtotal = cart.getItems().stream()
                .mapToDouble(item -> item.getSanpham().getGia() * item.getQuantity())
                .sum();

        String couponCode = (String) session.getAttribute("APPLIED_CART_COUPON");
        double discountAmount = 0.0;
        if (couponCode != null && !couponCode.trim().isEmpty()) {
            try {
                discountAmount = couponService.calculateDiscount(couponCode, subtotal);
            } catch (Exception e) {
                discountAmount = 0.0;
            }
        }

        double shippingFee = (subtotal >= 500000.0) ? 0.0 : 30000.0;
        double totalAmount = subtotal - discountAmount + shippingFee;

        model.addAttribute("subtotal", subtotal);
        model.addAttribute("discountAmount", discountAmount);
        model.addAttribute("shippingFee", shippingFee);
        model.addAttribute("totalAmount", totalAmount);
        model.addAttribute("couponCode", couponCode);

        return "ttap/checko";
    }

    @PostMapping("/checkout/process")
    public String processCheckout(HttpSession session,
                                  @RequestParam(value = "shippingAddress", required = false) String shippingAddress,
                                  RedirectAttributes redirectAttributes) {
        nguoidung customer = resolveActiveUser(session);
        if (customer == null) {
            return "redirect:/tt/lamb";
        }

        try {
            if (shippingAddress != null && !shippingAddress.trim().isEmpty()) {
                customer.setDc(shippingAddress);
            }

            Cart cart = cartService.getCartByUserId(customer.getId());
            if (cart == null || cart.getItems() == null || cart.getItems().isEmpty()) {
                redirectAttributes.addFlashAttribute("error", "Giỏ hàng của bạn đang trống!");
                return "redirect:/tt/giohang";
            }

            double subtotal = 0.0;
            for (CartItem item : cart.getItems()) {
                subtotal += item.getSanpham().getGia() * item.getQuantity();
            }

            double shippingFee = shippingService.calculateShippingFee(subtotal, ShippingRegion.OUTER_CITY);

            String couponCode = null;
            double discountAmount = 0.0;
            String appliedCouponCode = (String) session.getAttribute("APPLIED_CART_COUPON");

            if (appliedCouponCode != null && !appliedCouponCode.trim().isEmpty()) {
                try {
                    discountAmount = couponService.previewDiscount(appliedCouponCode, subtotal);
                    couponCode = appliedCouponCode;
                } catch (Exception e) {
                    // Bỏ qua mã lỗi/hết hạn
                }
            }

            double totalAmount = subtotal - discountAmount + shippingFee;
            if (totalAmount < 0) {
                totalAmount = 0;
            }

            Order newOrder = orderService.processCheckoutWithDetails(customer, cart, subtotal, shippingFee, discountAmount, totalAmount, couponCode);

            session.removeAttribute("APPLIED_CART_COUPON");
            session.removeAttribute("APPLIED_CART_COUPONS");

            redirectAttributes.addFlashAttribute("success", "Đặt hàng và thanh toán thành công cho đơn hàng #" + newOrder.getId() + "!");
            return "redirect:/tt/donhang/" + newOrder.getId();

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Giao dịch thất bại: " + e.getMessage());
            return "redirect:/tt/checkout";
        }
    }

    @GetMapping("/donhang")
    public String viewCustomerOrders(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        nguoidung currentUser = resolveActiveUser(session);
        if (currentUser == null) {
            redirectAttributes.addFlashAttribute("error", "Vui lòng đăng nhập để xem đơn hàng!");
            return "redirect:/tt/lamb";
        }

        List<Order> orders = orderRepository.findByNguoidungIdOrderByIdDesc(currentUser.getId());
        model.addAttribute("orders", orders);
        model.addAttribute("currentUser", currentUser);
        model.addAttribute("userEmail", currentUser.getEmail());
        return "/ttap/dh";
    }

    @GetMapping("/admin/donhang")
    public String viewAdminOrders(HttpSession session, Model model) {
        nguoidung currentUser = resolveActiveUser(session);
        List<Order> allOrders = orderRepository.findAllByOrderByIdDesc();
        model.addAttribute("orders", allOrders);
        model.addAttribute("currentUser", currentUser);
        model.addAttribute("userEmail", currentUser != null ? currentUser.getEmail() : null);
        return "/ttap/adminorders";
    }

    @GetMapping("/donhang/{id}")
    public String viewOrderDetail(@PathVariable("id") Integer orderId, HttpSession session, Model model) {
        nguoidung currentUser = resolveActiveUser(session);
        if (currentUser == null) {
            return "redirect:/tt/lamb";
        }

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy đơn hàng!"));

        boolean isAdmin = Boolean.TRUE.equals(currentUser.getVaitro());
        if (!isAdmin && !order.getNguoidung().getId().equals(currentUser.getId())) {
            return "redirect:/tt/donhang";
        }

        model.addAttribute("isAdmin", isAdmin);
        model.addAttribute("order", order);
        model.addAttribute("currentUser", currentUser);
        model.addAttribute("userEmail", currentUser.getEmail());
        return "/ttap/odetail";
    }

    @PostMapping("/admin/donhang/updatetrangthai")
    public String updateOrderStatus(@RequestParam("orderId") Integer orderId,
                                    @RequestParam("newStatus") OrderStatus newStatus,
                                    @RequestParam(value = "note", required = false) String note,
                                    HttpSession session,
                                    RedirectAttributes redirectAttributes) {
        nguoidung currentUser = resolveActiveUser(session);
        if (currentUser == null) {
            return "redirect:/tt/lamb";
        }

        try {
            orderService.updateOrderStatusByAdmin(orderId, newStatus, currentUser, note);
            redirectAttributes.addFlashAttribute("success", "Cập nhật trạng thái đơn hàng thành công!");
            return "redirect:/tt/admin/donhang";
        } catch (IllegalStateException | IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/tt/admin/donhang/" + orderId + "/suatrangthai";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Đã xảy ra lỗi khi cập nhật trạng thái đơn hàng.");
            return "redirect:/tt/admin/donhang/" + orderId + "/suatrangthai";
        }
    }

    @PostMapping("/donhang/{id}/huy")
    public String cancelCustomerOrder(@PathVariable("id") Integer orderId,
                                      HttpSession session,
                                      RedirectAttributes redirectAttributes) {
        nguoidung currentUser = resolveActiveUser(session);
        if (currentUser == null) {
            return "redirect:/tt/lamb";
        }

        try {
            orderService.updateOrderStatus(orderId, OrderStatus.CANCELLED, currentUser, "Khách hàng tự hủy đơn hàng");
            redirectAttributes.addFlashAttribute("success", "Đã hủy đơn hàng #" + orderId + " thành công và hoàn lại tồn kho.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Không thể hủy đơn hàng: " + e.getMessage());
        }

        return "redirect:/tt/donhang/" + orderId;
    }

    @GetMapping("/admin/donhang/{id}/suatrangthai")
    public String showEditOrderStatusForm(@PathVariable("id") Integer orderId,
                                          HttpSession session,
                                          Model model,
                                          RedirectAttributes redirectAttributes) {
        nguoidung currentUser = resolveActiveUser(session);
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy đơn hàng #" + orderId));

        model.addAttribute("order", order);
        model.addAttribute("currentUser", currentUser);
        model.addAttribute("userEmail", currentUser != null ? currentUser.getEmail() : null);
        return "/ttap/orderdetail";
    }

    @PostMapping("/donhang/{id}/retry-payment")
    public String retryPayment(@PathVariable("id") Integer orderId,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {
        nguoidung customer = resolveActiveUser(session);
        if (customer == null) {
            redirectAttributes.addFlashAttribute("error", "Vui lòng đăng nhập để tiếp tục!");
            return "redirect:/tt/lamb";
        }

        try {
            orderService.retryPayment(orderId, customer);
            redirectAttributes.addFlashAttribute("success", "Thanh toán thành công cho đơn hàng #" + orderId + "!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Thanh toán lại thất bại: " + e.getMessage());
        }

        return "redirect:/tt/donhang/" + orderId;
    }

    @GetMapping("/buynow/process")
    public String viewBuyNowCheckout(@RequestParam("productId") Integer productId,
                                     @RequestParam("quantity") Integer quantity,
                                     HttpSession session,
                                     Model model,
                                     RedirectAttributes redirectAttributes) {
        nguoidung customer = resolveActiveUser(session);
        if (customer == null) {
            redirectAttributes.addFlashAttribute("error", "Vui lòng đăng nhập để thanh toán!");
            return "redirect:/tt/lamb";
        }

        session.setAttribute("BUY_NOW_PRODUCT_ID", productId);
        session.setAttribute("BUY_NOW_QUANTITY", quantity);

        if (productId == null || quantity == null) {
            redirectAttributes.addFlashAttribute("error", "Sản phẩm mua ngay không hợp lệ!");
            return "redirect:/tt/sp";
        }

        sanpham product = sphamre.findById(productId)
                .orElseThrow(() -> new RuntimeException("Sản phẩm không tồn tại!"));

        double subtotal = product.getGia() * quantity;
        double shippingFee = 30000.0;
        double discountAmount = 0.0;

        String appliedCouponCode = (String) session.getAttribute("APPLIED_COUPON_CODE");
        if (appliedCouponCode != null && !appliedCouponCode.trim().isEmpty()) {
            try {
                discountAmount = couponService.previewDiscount(appliedCouponCode, subtotal);
                model.addAttribute("appliedCouponCode", appliedCouponCode);
                model.addAttribute("discountAmount", discountAmount);
            } catch (Exception e) {
                session.removeAttribute("APPLIED_COUPON_CODE");
            }
        }

        double totalAmount = subtotal - discountAmount + shippingFee;

        model.addAttribute("customer", customer);
        model.addAttribute("currentUser", customer);
        model.addAttribute("userEmail", customer.getEmail());
        model.addAttribute("product", product);
        model.addAttribute("quantity", quantity);
        model.addAttribute("subtotal", subtotal);
        model.addAttribute("shippingFee", shippingFee);
        model.addAttribute("discountAmount", discountAmount);
        model.addAttribute("totalAmount", totalAmount);

        return "/ttap/checkoutnow";
    }

    @PostMapping("/buy-now/checkout-process")
    public String confirmBuyNow(@RequestParam("shippingAddress") String shippingAddress,
                                @RequestParam(value = "paymentMethod", required = false, defaultValue = "COD") String paymentMethod,
                                HttpSession session,
                                RedirectAttributes redirectAttributes) {
        nguoidung customer = resolveActiveUser(session);
        if (customer == null) {
            redirectAttributes.addFlashAttribute("error", "Vui lòng đăng nhập để thanh toán!");
            return "redirect:/tt/lamb";
        }

        Integer productId = (Integer) session.getAttribute("BUY_NOW_PRODUCT_ID");
        Integer quantity = (Integer) session.getAttribute("BUY_NOW_QUANTITY");

        if (productId == null || quantity == null) {
            redirectAttributes.addFlashAttribute("error", "Không tìm thấy thông tin sản phẩm mua ngay!");
            return "redirect:/tt/sp";
        }

        sanpham product = sphamre.findById(productId)
                .orElseThrow(() -> new RuntimeException("Sản phẩm không tồn tại!"));

        int currentStock = product.getStock() == null ? 0 : product.getStock();
        int currentReserve = product.getReserve() == null ? 0 : product.getReserve();
        int availableStock = currentStock - currentReserve;

        if (quantity <= 0 || availableStock < quantity) {
            redirectAttributes.addFlashAttribute("error", "Sản phẩm đã hết hàng hoặc không đủ số lượng khả dụng!");
            return "redirect:/tt/sp";
        }

        double subtotal = product.getGia() * quantity;
        double shippingFee = shippingService.calculateShippingFee(subtotal, ShippingRegion.OUTER_CITY);

        double discountAmount = 0.0;
        String couponCode = null;
        String appliedCouponCode = (String) session.getAttribute("APPLIED_COUPON_CODE");
        if (appliedCouponCode != null && !appliedCouponCode.trim().isEmpty()) {
            try {
                discountAmount = couponService.previewDiscount(appliedCouponCode, subtotal);
                couponCode = appliedCouponCode;
            } catch (Exception e) {
                // Mã không hợp lệ
            }
        }

        double totalAmount = subtotal - discountAmount + shippingFee;
        if (totalAmount < 0) totalAmount = 0;

        Order order = new Order();
        order.setNguoidung(customer);
        order.setShippingAddress(shippingAddress);
        order.setSubtotal(subtotal);
        order.setShippingFee(shippingFee);
        order.setDiscountAmount(discountAmount);
        order.setTotalAmount(totalAmount);
        order.setCouponCode(couponCode);
        order.setStatus(OrderStatus.PENDING);
        order.setCreatedAt(LocalDateTime.now());

        List<OItem> orderItems = new ArrayList<>();
        OItem oItem = new OItem();
        oItem.setOrder(order);
        oItem.setSanpham(product);
        oItem.setQuantity(quantity);
        oItem.setUnitPrice(product.getGia());
        orderItems.add(oItem);
        order.setItems(orderItems);

        Order savedOrder = orderRepository.saveAndFlush(order);

        product.setReserve(currentReserve + quantity);
        sphamre.saveAndFlush(product);

        payment paymentRecord = new payment();
        paymentRecord.setOrder(savedOrder);
        paymentRecord.setAmount(totalAmount);
        paymentRecord.setStatus(PaymentStatus.INITIATED);
        paymentRecord.setCreatedAt(LocalDateTime.now());
        if ("COD".equalsIgnoreCase(paymentMethod) || "CASH".equalsIgnoreCase(paymentMethod)) {
            paymentRecord.setTransactionCode("CASH_PENDING_ORDER_" + savedOrder.getId());
        }
        paymentRepository.saveAndFlush(paymentRecord);

        session.removeAttribute("BUY_NOW_PRODUCT_ID");
        session.removeAttribute("BUY_NOW_QUANTITY");
        session.removeAttribute("APPLIED_COUPON_CODE");

        redirectAttributes.addFlashAttribute("success", "Đặt hàng thành công cho đơn hàng #" + savedOrder.getId() + "!");
        return "redirect:/tt/donhang/" + savedOrder.getId();
    }

    @PostMapping("/buy-now/apply-coupon")
    public String applyCoupon(@RequestParam("couponCode") String code,
                              @RequestParam("productId") Integer productId,
                              @RequestParam("quantity") Integer quantity,
                              HttpSession session,
                              RedirectAttributes redirectAttributes) {
        sanpham product = sphamre.findById(productId).orElse(null);
        if (product == null) {
            redirectAttributes.addFlashAttribute("error", "Sản phẩm không tồn tại!");
            return "redirect:/tt/sp";
        }

        double subtotal = product.getGia() * quantity;

        try {
            couponService.previewDiscount(code, subtotal);
            session.setAttribute("APPLIED_COUPON_CODE", code.trim());
            redirectAttributes.addFlashAttribute("success", "Áp dụng mã giảm giá thành công!");
        } catch (Exception e) {
            session.removeAttribute("APPLIED_COUPON_CODE");
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }

        return "redirect:/tt/buynow/process?productId=" + productId + "&quantity=" + quantity;
    }

    @PostMapping("/buy-now/remove-coupon")
    public String removeCoupon(@RequestParam("productId") Integer productId,
                               @RequestParam("quantity") Integer quantity,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {
        session.removeAttribute("APPLIED_COUPON_CODE");
        redirectAttributes.addFlashAttribute("success", "Đã hủy mã giảm giá.");
        return "redirect:/tt/buynow/process?productId=" + productId + "&quantity=" + quantity;
    }

    @PostMapping("/giohang/apply-coupon")
    public String applyCartCoupon(@RequestParam("couponCode") String code,
                                  HttpSession session,
                                  RedirectAttributes redirectAttributes) {
        nguoidung customer = resolveActiveUser(session);
        if (customer == null) {
            return "redirect:/tt/lamb";
        }

        Cart userCart = cartService.getCartByUserId(customer.getId());
        if (userCart == null || userCart.getItems() == null || userCart.getItems().isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Giỏ hàng trống!");
            return "redirect:/tt/giohang";
        }

        double tongTien = userCart.getItems().stream()
                .mapToDouble(item -> item.getSanpham().getGia() * item.getQuantity())
                .sum();

        try {
            couponService.previewDiscount(code, tongTien);
            session.setAttribute("APPLIED_CART_COUPON", code.trim());
            redirectAttributes.addFlashAttribute("success", "Áp dụng mã giảm giá thành công!");
        } catch (Exception e) {
            session.removeAttribute("APPLIED_CART_COUPON");
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }

        return "redirect:/tt/giohang";
    }

    @PostMapping("/giohang/remove-coupon")
    public String removeCartCoupon(HttpSession session, RedirectAttributes redirectAttributes) {
        session.removeAttribute("APPLIED_CART_COUPON");
        redirectAttributes.addFlashAttribute("success", "Đã hủy mã giảm giá.");
        return "redirect:/tt/giohang";
    }

    @PostMapping("/review/add")
    public String addReview(@RequestParam("productId") Integer productId,
                            @RequestParam("rating") int rating,
                            @RequestParam("comment") String comment,
                            HttpSession session,
                            RedirectAttributes redirectAttributes) {
        nguoidung customer = resolveActiveUser(session);
        if (customer == null) {
            return "redirect:/tt/lamb";
        }

        try {
            reviewService.addReview(customer, productId, rating, comment);
            redirectAttributes.addFlashAttribute("success", "Đánh giá sản phẩm thành công!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }

        return "redirect:/tt/xemsanpham/" + productId;
    }

    @PostMapping("/review/delete/{id}")
    public String deleteReview(@PathVariable("id") Integer reviewId,
                               @RequestParam("productId") Integer productId,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {
        nguoidung customer = resolveActiveUser(session);
        if (customer == null) {
            return "redirect:/tt/lamb";
        }

        try {
            reviewService.deleteReview(reviewId, customer);
            redirectAttributes.addFlashAttribute("success", "Đã xóa đánh giá thành công!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }

        return "redirect:/tt/xemsanpham/" + productId;
    }

    @GetMapping("/admin/baocao")
    public String viewAdminReport(HttpSession session,
                                  RedirectAttributes redirectAttributes,
                                  Model model) {
        nguoidung currentUser = resolveActiveUser(session);
        model.addAttribute("currentUser", currentUser);
        model.addAttribute("userEmail", currentUser != null ? currentUser.getEmail() : null);
        model.addAllAttributes(adminDashboardService.getDashboardSummary(5));
        return "/ttap/bc";
    }

    @GetMapping("/admin/users")
    public String listUsers(@RequestParam(value = "q", required = false) String q,
                            @RequestParam(value = "role", required = false, defaultValue = "ALL") String role,
                            @RequestParam(value = "viewId", required = false) Integer viewId,
                            HttpSession session,
                            Model model) {
        nguoidung currentUser = resolveActiveUser(session);
        model.addAttribute("currentUser", currentUser);
        model.addAttribute("userEmail", currentUser != null ? currentUser.getEmail() : null);
        model.addAttribute("users", nguoidungAdminService.searchUsers(q, role));
        model.addAttribute("q", q);
        model.addAttribute("roleFilter", role);

        if (viewId != null) {
            model.addAttribute("selectedUser", nguoidungAdminService.findById(viewId));
        }
        return "/ttap/users";
    }

    @PostMapping("/admin/users/{id}/delete")
    public String deleteUser(@PathVariable("id") Integer id,
                             HttpSession session,
                             RedirectAttributes redirectAttributes) {
        try {
            nguoidung loggedInUser = resolveActiveUser(session);
            Integer currentUserId = loggedInUser != null ? loggedInUser.getId() : null;
            nguoidungAdminService.deleteUser(id, currentUserId);
            redirectAttributes.addFlashAttribute("success", "Đã xóa người dùng #" + id + ".");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Không thể xóa người dùng #" + id + ": " + e.getMessage());
        }
        return "redirect:/tt/admin/users";
    }
}