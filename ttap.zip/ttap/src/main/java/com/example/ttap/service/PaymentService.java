//package com.example.ttap.service;
//
//import com.example.ttap.entity.Order;
//import com.example.ttap.entity.OrderStatus;
//import com.example.ttap.entity.payment;
//import com.example.ttap.entity.PaymentStatus;
//import com.example.ttap.entity.nguoidung;
//import com.example.ttap.repository.orderre;
//import com.example.ttap.repository.PaymentRepository;
//import jakarta.persistence.criteria.CriteriaBuilder;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import java.time.LocalDateTime;
//import java.util.Set;
//
//@Service
//public class PaymentService {
//
//    // Các trạng thái Order cho phép khởi tạo / thử lại thanh toán (không cho khi đã PAID, DELIVERED, CANCELLED...)
//    private static final Set<OrderStatus> PAYABLE_ORDER_STATUSES = Set.of(
//            OrderStatus.PENDING
//    );
//
//    private final PaymentRepository paymentRepository;
//    private final orderre orderRepository;
//    private final MockPaymentGatewayService gatewayService;
//
//    public PaymentService(PaymentRepository paymentRepository,
//                          orderre orderRepository,
//                          MockPaymentGatewayService gatewayService) {
//        this.paymentRepository = paymentRepository;
//        this.orderRepository = orderRepository;
//        this.gatewayService = gatewayService;
//    }
//
//    /**
//     * Bước 1: Tạo bản ghi Payment ở trạng thái INITIATED.
//     * Tuyệt đối KHÔNG tự động chuyển Order sang PAID chỉ vì tạo Payment record.
//     */
//    @Transactional
//    public payment initiatePayment(Integer orderId, nguoidung customer) {
//        Order order = getValidatedOrderForCustomer(orderId, customer);
//
//        if (paymentRepository.existsByOrderIdAndStatus(order.getId(), PaymentStatus.SUCCESS)) {
//            throw new IllegalStateException("Đơn hàng này đã được thanh toán thành công trước đó.");
//        }
//
//        payment payment = new payment();
//        payment.setOrder(order);
//        payment.setAmount(order.getTotalAmount());
//        payment.setStatus(PaymentStatus.INITIATED);
//        payment.setCreatedAt(LocalDateTime.now());
//
//        // Chỉ lưu Payment với INITIATED; giữ nguyên order.getStatus() (ví dụ PENDING)
//        return paymentRepository.saveAndFlush(payment);
//    }
//
//    /**
//     * Bước 2: Gửi giao dịch qua Payment Gateway mô phỏng và cập nhật trạng thái Payment.
//     * Chỉ khi gateway trả SUCCESS mới điều phối chuyển Order sang trạng thái hợp lệ (ví dụ PAID).
//     */
//    @Transactional
//    public payment executeGatewayCharge(Integer paymentId, nguoidung customer, String requestedOutcome) {
//        payment payment = paymentRepository.findById(paymentId)
//                .orElseThrow(() -> new RuntimeException("Không tìm thấy giao dịch thanh toán #" + paymentId));
//
//        Order order = getValidatedOrderForCustomer(payment.getOrder().getId(), customer);
//
//        if (payment.getStatus() == PaymentStatus.SUCCESS) {
//            return payment;
//        }
//        if (payment.getStatus() == PaymentStatus.REFUNDED) {
//            throw new IllegalStateException("Giao dịch đã hoàn tiền, không thể xử lý tiếp.");
//        }
//
//        GatewaySimulationResult result = gatewayService.processPayment(
//                order.getId(),
//                payment.getAmount(),
//                requestedOutcome
//        );
//
//        payment.setTransactionCode(result.transactionRef());
//        payment.setUpdatedAt(LocalDateTime.now());
//
//        if (result.success()) {
//            payment.setStatus(PaymentStatus.SUCCESS);
//            payment.setFailureReason(null);
//            paymentRepository.saveAndFlush(payment);
//
//            // Chuyển Order sang PAID qua kiểm tra trạng thái hợp lệ
//            transitionOrderToPaid(order);
//        } else {
//            payment.setStatus(PaymentStatus.FAILED);
//            payment.setFailureReason(result.failureReason());
//            paymentRepository.saveAndFlush(payment);
//
//            // Order KHÔNG chuyển sang PAID; giữ nguyên trạng thái hiện tại (ví dụ PENDING) để customer có thể retry
//        }
//
//        return payment;
//    }
//
//    /**
//     * Cho phép customer thanh toán lại (retry) trên CHÍNH Order hiện tại (không tạo Order mới)
//     * nếu Order còn ở trạng thái phù hợp và chưa có Payment SUCCESS.
//     */
//    @Transactional
//    public payment retryPayment(Integer orderId, nguoidung customer, String requestedOutcome) {
//        Order order = getValidatedOrderForCustomer(orderId, customer);
//
//        if (!PAYABLE_ORDER_STATUSES.contains(order.getStatus())) {
//            throw new IllegalStateException(
//                    "Không thể thanh toán lại vì đơn hàng đang ở trạng thái " + order.getStatus()
//            );
//        }
//
//        if (paymentRepository.existsByOrderIdAndStatus(order.getId(), PaymentStatus.SUCCESS)) {
//            throw new IllegalStateException("Đơn hàng này đã thanh toán thành công, không cần thanh toán lại.");
//        }
//
//        // Tạo lần thanh toán mới gắn với CÙNG order (không tạo Order mới)
//        payment newAttempt = initiatePayment(order.getId(), customer);
//        return executeGatewayCharge(newAttempt.getId(), customer, requestedOutcome);
//    }
//
//    /**
//     * Hoàn tiền cho giao dịch đã SUCCESS (chỉ gọi khi có quyền phù hợp / admin).
//     */
//    @Transactional
//    public payment refundPayment(Integer paymentId) {
//        payment payment = paymentRepository.findById(paymentId)
//                .orElseThrow(() -> new RuntimeException("Không tìm thấy giao dịch #" + paymentId));
//
//        if (payment.getStatus() != PaymentStatus.SUCCESS) {
//            throw new IllegalStateException("Chỉ có thể hoàn tiền cho giao dịch đang ở trạng thái SUCCESS.");
//        }
//
//        payment.setStatus(PaymentStatus.REFUNDED);
//        payment.setUpdatedAt(LocalDateTime.now());
//        return paymentRepository.saveAndFlush(payment);
//    }
//
//    private Order getValidatedOrderForCustomer(Integer orderId, nguoidung customer) {
//        if (customer == null) {
//            throw new RuntimeException("Vui lòng đăng nhập để thực hiện thanh toán.");
//        }
//
//        Order order = orderRepository.findById(orderId)
//                .orElseThrow(() -> new RuntimeException("Không tìm thấy đơn hàng #" + orderId));
//
//        if (order.getNguoidung() == null || !order.getNguoidung().getId().equals(customer.getId())) {
//            throw new SecurityException("Bạn không có quyền thao tác thanh toán trên đơn hàng này.");
//        }
//
//        if (!PAYABLE_ORDER_STATUSES.contains(order.getStatus())) {
//            throw new IllegalStateException(
//                    "Đơn hàng #" + order.getId() + " không ở trạng thái cho phép thanh toán (hiện tại: " + order.getStatus() + ")."
//            );
//        }
//
//        return order;
//    }
//
//    private void transitionOrderToPaid(Order order) {
//        if (order.getStatus() == OrderStatus.CANCELLED || order.getStatus() == OrderStatus.DELIVERED) {
//            throw new IllegalStateException("Không thể chuyển đơn hàng sang PAID từ trạng thái " + order.getStatus());
//        }
//        if (order.getStatus() == OrderStatus.PENDING) {
//            order.setStatus(OrderStatus.PAID);
//            orderRepository.saveAndFlush(order);
//        }
//    }
//    public boolean processPayment(Integer orderId, double amount) {
//        // [TÙY CHỌN 1]: Random ngẫu nhiên (Ví dụ 80% thành công, 20% thất bại để test)
//        // boolean isSuccess = random.nextInt(100) < 80;
//
//        // [TÙY CHỌN 2]: Mặc định trả về SUCCESS để dễ test luồng mua hàng bình thường,
//        // bạn có thể đổi thành false để test luồng rollback khi thanh toán lỗi.
//        boolean isSuccess = true;
//
//        // Giả lập độ trễ mạng khi gọi cổng thanh toán (Network latency)
//        try {
//            Thread.sleep(500);
//        } catch (InterruptedException e) {
//            Thread.currentThread().interrupt();
//        }
//
//        return isSuccess;
//    }
//}
package com.example.ttap.service;

import com.example.ttap.entity.Order;
import com.example.ttap.entity.OrderStatus;
import com.example.ttap.entity.PaymentStatus;
import com.example.ttap.entity.nguoidung;
import com.example.ttap.entity.payment;
import com.example.ttap.repository.orderre;
import com.example.ttap.repository.PaymentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

@Service
public class PaymentService {

    private static final Set<OrderStatus> PAYABLE_ORDER_STATUSES = Set.of(
            OrderStatus.PENDING
    );

    private final PaymentRepository paymentRepository;
    private final orderre orderRepository;
    private final MockPaymentGatewayService gatewayService;

    public PaymentService(PaymentRepository paymentRepository,
                          orderre orderRepository,
                          MockPaymentGatewayService gatewayService) {
        this.paymentRepository = paymentRepository;
        this.orderRepository = orderRepository;
        this.gatewayService = gatewayService;
    }

    /**
     * Tạo bản ghi Payment tiền mặt ở trạng thái INITIATED (chưa thu tiền).
     * Không tự động đổi Order sang PAID.
     */
    @Transactional
    public payment createCashPayment(Integer orderId, nguoidung customer) {
        if (customer == null) {
            throw new RuntimeException("Vui lòng đăng nhập.");
        }

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy đơn hàng #" + orderId));

        if (order.getNguoidung() == null || !order.getNguoidung().getId().equals(customer.getId())) {
            throw new SecurityException("Bạn không có quyền thao tác trên đơn hàng này.");
        }

        if (order.getStatus() == OrderStatus.CANCELLED) {
            throw new IllegalStateException("Đơn hàng đã bị hủy, không thể tạo thanh toán tiền mặt.");
        }

        if (paymentRepository.existsByOrderIdAndStatus(order.getId(), PaymentStatus.SUCCESS)) {
            throw new IllegalStateException("Đơn hàng này đã được thanh toán thành công.");
        }

        return paymentRepository.findTopByOrderIdAndStatusOrderByCreatedAtDesc(order.getId(), PaymentStatus.INITIATED)
                .orElseGet(() -> {
                    payment cashPayment = new payment();
                    cashPayment.setOrder(order);
                    cashPayment.setAmount(order.getTotalAmount());
                    cashPayment.setStatus(PaymentStatus.INITIATED);
                    cashPayment.setCreatedAt(LocalDateTime.now());
                    // Nếu entity payment có trường phương thức thanh toán thì bật dòng dưới:
                    // cashPayment.setPaymentMethod("CASH");
                    return paymentRepository.saveAndFlush(cashPayment);
                });
    }

    /**
     * Admin đổi trạng thái thanh toán của đơn hàng và đồng bộ trạng thái Order hợp lệ.
     */
    @Transactional
    public payment adminUpdateOrderPaymentStatus(Integer orderId, PaymentStatus targetStatus, String note) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy đơn hàng #" + orderId));

        payment latestPayment = paymentRepository.findTopByOrderIdOrderByCreatedAtDesc(orderId)
                .orElseThrow(() -> new RuntimeException("Đơn hàng #" + orderId + " chưa có bản ghi thanh toán nào."));

        PaymentStatus current = latestPayment.getStatus();
        if (current == targetStatus) {
            syncOrderWithPayment(order, targetStatus);
            return latestPayment;
        }

        // 1. INITIATED -> SUCCESS: Admin xác nhận đã thu tiền mặt / thanh toán thành công
        if (current == PaymentStatus.INITIATED && targetStatus == PaymentStatus.SUCCESS) {
            if (order.getStatus() == OrderStatus.CANCELLED) {
                throw new IllegalStateException("Không thể xác nhận thanh toán cho đơn hàng đã CANCELLED.");
            }
            latestPayment.setStatus(PaymentStatus.SUCCESS);
            latestPayment.setFailureReason(null);
            if (latestPayment.getTransactionCode() == null || latestPayment.getTransactionCode().isBlank()) {
                String ref = "CASH_ORDER_" + order.getId();
                if (note != null && !note.isBlank()) {
                    ref += " (" + note.trim() + ")";
                }
                latestPayment.setTransactionCode(ref);
            }
            latestPayment.setUpdatedAt(LocalDateTime.now());
            paymentRepository.saveAndFlush(latestPayment);

            transitionOrderToPaid(order);
            return latestPayment;
        }

        // 2. INITIATED -> FAILED: Không thu được tiền / hủy giao dịch
        if (current == PaymentStatus.INITIATED && targetStatus == PaymentStatus.FAILED) {
            latestPayment.setStatus(PaymentStatus.FAILED);
            latestPayment.setFailureReason(
                    (note != null && !note.isBlank()) ? note.trim() : "Admin đánh dấu thanh toán thất bại."
            );
            latestPayment.setUpdatedAt(LocalDateTime.now());
            paymentRepository.saveAndFlush(latestPayment);
            return latestPayment;
        }

        // 3. SUCCESS -> REFUNDED: Hoàn tiền cho giao dịch đã thành công
        if (current == PaymentStatus.SUCCESS && targetStatus == PaymentStatus.REFUNDED) {
            latestPayment.setStatus(PaymentStatus.REFUNDED);
            latestPayment.setUpdatedAt(LocalDateTime.now());
            paymentRepository.saveAndFlush(latestPayment);

            if (order.getStatus() == OrderStatus.PAID) {
                order.setStatus(OrderStatus.CANCELLED);
                orderRepository.saveAndFlush(order);
            }
            return latestPayment;
        }

        throw new IllegalStateException(
                "Không thể chuyển trạng thái thanh toán từ " + current + " sang " + targetStatus
        );
    }

    public List<payment> getPaymentsByOrderId(Integer orderId) {
        return paymentRepository.findByOrderIdOrderByCreatedAtDesc(orderId);
    }

    private void syncOrderWithPayment(Order order, PaymentStatus paymentStatus) {
        if (paymentStatus == PaymentStatus.SUCCESS) {
            transitionOrderToPaid(order);
        }
    }

    private void transitionOrderToPaid(Order order) {
        if (order.getStatus() == OrderStatus.CANCELLED || order.getStatus() == OrderStatus.DELIVERED) {
            throw new IllegalStateException("Không thể chuyển đơn hàng sang PAID từ trạng thái " + order.getStatus());
        }
        if (PAYABLE_ORDER_STATUSES.contains(order.getStatus())) {
            order.setStatus(OrderStatus.PAID);
            orderRepository.saveAndFlush(order);
        }
    }
    public boolean processPayment(Integer orderId, double amount) {
        // [TÙY CHỌN 1]: Random ngẫu nhiên (Ví dụ 80% thành công, 20% thất bại để test)
        // boolean isSuccess = random.nextInt(100) < 80;

        // [TÙY CHỌN 2]: Mặc định trả về SUCCESS để dễ test luồng mua hàng bình thường,
        // bạn có thể đổi thành false để test luồng rollback khi thanh toán lỗi.
        boolean isSuccess = true;

        // Giả lập độ trễ mạng khi gọi cổng thanh toán (Network latency)
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        return isSuccess;
    }
}