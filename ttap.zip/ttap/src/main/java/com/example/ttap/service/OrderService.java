//package com.example.ttap.service;
//
//import com.example.ttap.entity.*;
//import com.example.ttap.repository.CartRepository;
//import com.example.ttap.repository.PaymentRepository;
//import com.example.ttap.repository.orderre;
//import com.example.ttap.repository.sphamre;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.cache.annotation.CacheEvict;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import java.time.LocalDateTime;
//import java.util.ArrayList;
//import java.util.List;
//
//@Service
//public class OrderService {
//
//    @Autowired
//    private sphamre sanphamRepository;
//
//    @Autowired
//    private CartRepository cartRepository;
//
//    @Autowired
//    private orderre orderRepository;
//
//@Autowired
//PaymentGatewayService paymentGatewayService;
//@Autowired
//    PaymentRepository paymentRepository;
//    /**
//     * 1. Phương thức kiểm tra và mua nhanh 1 sản phẩm riêng lẻ với khóa bi quan
//     */
//    @Transactional
//    public boolean checkoutProduct(Integer productId, int quantityToBuy) {
//        // 1. Tìm sản phẩm và khóa dòng dữ liệu này ngay lập tức
//        sanpham sp = sanphamRepository.findByIdWithLock(productId)
//                .orElseThrow(() -> new RuntimeException("Không tìm thấy sản phẩm"));
//
//        // 2. Kiểm tra số lượng khả dụng (Available = Stock - Reserve)
//        int available = sp.getStock() - (sp.getReserve() != null ? sp.getReserve() : 0);
//
//        if (available < quantityToBuy) {
//            throw new RuntimeException("Sản phẩm đã hết hàng hoặc không đủ số lượng khả dụng!");
//        }
//
//        // 3. Tiến hành trừ kho an toàn
//        sp.setStock(sp.getStock() - quantityToBuy);
//        sanphamRepository.save(sp);
//
//        return true;
//    }
//
//    /**
//     * 2. Phương thức tạo đơn hàng cơ bản từ giỏ hàng (Hỗ trợ snapshot giá)
//     */
//    @Transactional
//    public Order createOrderFromCart(nguoidung customer) {
//        // 1. Lấy giỏ hàng active của user
//        Cart cart = cartRepository.findByNguoidungId(customer.getId())
//                .orElseThrow(() -> new RuntimeException("Giỏ hàng trống!"));
//
//        if (cart.getItems() == null || cart.getItems().isEmpty()) {
//            throw new RuntimeException("Không có sản phẩm nào trong giỏ hàng để thanh toán!");
//        }
//
//        Order newOrder = new Order();
//        newOrder.setNguoidung(customer);
//        double totalOrderAmount = 0;
//
//        // 2. Duyệt qua từng item trong giỏ hàng
//        for (CartItem cartItem : cart.getItems()) {
//            Integer productId = cartItem.getSanpham().getId();
//            int quantityToBuy = cartItem.getQuantity();
//
//            // KHOÁ BI QUAN: Chống tranh chấp kho đồng thời
//            sanpham product = sanphamRepository.findByIdWithLock(productId)
//                    .orElseThrow(() -> new RuntimeException("Sản phẩm " + cartItem.getSanpham().getTen() + " không tồn tại!"));
//
//            // Kiểm tra tồn kho khả dụng
//            int available = product.getStock() - (product.getReserve() != null ? product.getReserve() : 0);
//            if (available < quantityToBuy) {
//                throw new RuntimeException("Sản phẩm [" + product.getTen() + "] vừa thay đổi tồn kho hoặc không đủ số lượng!");
//            }
//
//            // Lấy GIÁ HIỆN TẠI mới nhất từ Database (Snapshot giá)
//            double currentUnitPrice = product.getGia();
//
//            // Trừ kho trực tiếp
//            product.setStock(product.getStock() - quantityToBuy);
//            sanphamRepository.save(product);
//
//            // Tạo OItem và lưu snapshot giá tại thời điểm mua
//            OItem orderItem = new OItem();
//            orderItem.setOrder(newOrder);
//            orderItem.setSanpham(product);
//            orderItem.setQuantity(quantityToBuy);
//            orderItem.setUnitPrice(currentUnitPrice);
//
//            newOrder.getItems().add(orderItem);
//            totalOrderAmount += (currentUnitPrice * quantityToBuy);
//        }
//
//        newOrder.setTotalAmount(totalOrderAmount);
//        newOrder.setStatus(OrderStatus.PENDING); // Sử dụng Enum trạng thái chuẩn
//
//        // Lưu đơn hàng vào Database
//        orderRepository.save(newOrder);
//
//        // 3. Sau khi tạo đơn thành công, làm sạch giỏ hàng
//        cart.getItems().clear();
//        cartRepository.save(cart);
//
//        return newOrder;
//    }
//
//    /**
//     * 3. Phương thức Checkout đầy đủ (Snapshot địa chỉ, snapshot giá, active check, khóa kho)
//     */
////    @Transactional
////    public Order processCheckout(nguoidung customer) {
////        // 1. KIỂM TRA GIỎ HÀNG KHÔNG ĐƯỢC TRỐNG
////        Cart cart = cartRepository.findByNguoidungId(customer.getId())
////                .orElseThrow(() -> new RuntimeException("Giỏ hàng của bạn không tồn tại!"));
////
////        if (cart.getItems() == null || cart.getItems().isEmpty()) {
////            throw new RuntimeException("Giỏ hàng đang trống, không thể tiến hành thanh toán!");
////        }
////
////        // 2. TẠO ĐƠN HÀNG MỚI VÀ SNAPSHOT ĐỊA CHỈ GIAO HÀNG
////        Order newOrder = new Order();
////        newOrder.setNguoidung(customer);
////
////        String shippingAddressSnapshot = (customer.getDc() != null && !customer.getDc().trim().isEmpty())
////                ? customer.getDc()
////                : "Địa chỉ mặc định của khách hàng";
////        newOrder.setShippingAddress(shippingAddressSnapshot);
////
////        double calculatedSubtotal = 0;
////
////        // 3. DUYỆT QUA TỪNG ITEM: KHÓA KHO, CHECK ACTIVE, CHECK STOCK & SNAPSHOT GIÁ
////        for (CartItem cartItem : cart.getItems()) {
////            Integer productId = cartItem.getSanpham().getId();
////            int quantityToBuy = cartItem.getQuantity();
////
////            // Sử dụng Khóa bi quan (Pessimistic Lock) để chống overselling
////            sanpham product = sanphamRepository.findByIdWithLock(productId)
////                    .orElseThrow(() -> new RuntimeException("Sản phẩm [" + cartItem.getSanpham().getTen() + "] không còn tồn tại!"));
////
////            // Kiểm tra sản phẩm còn active (ti == true) hay không
////            if (product.getTi() == null || !product.getTi()) {
////                throw new RuntimeException("Sản phẩm [" + product.getTen() + "] hiện đã ngừng kinh doanh.");
////            }
////
////            // Kiểm tra tồn kho khả dụng (Available = Stock - Reserve)
////            int availableQuantity = product.getStock() - (product.getReserve() != null ? product.getReserve() : 0);
////            if (availableQuantity < quantityToBuy) {
////                throw new RuntimeException("Sản phẩm [" + product.getTen() + "] không đủ số lượng tồn kho (Chỉ còn: " + availableQuantity + ").");
////            }
////
////            // Lấy giá hiện tại mới nhất từ Database
////            double currentUnitPrice = product.getGia();
////
////            // Trừ trực tiếp số lượng tồn kho
////            product.setStock(product.getStock() - quantityToBuy);
////            sanphamRepository.save(product);
////
////            // Tạo OItem và khóa chặt (snapshot) giá tại thời điểm mua
////            OItem orderItem = new OItem();
////            orderItem.setOrder(newOrder);
////            orderItem.setSanpham(product);
////            orderItem.setQuantity(quantityToBuy);
////            orderItem.setUnitPrice(currentUnitPrice);
////
////            newOrder.getItems().add(orderItem);
////            calculatedSubtotal += (currentUnitPrice * quantityToBuy);
////        }
////
////        // 4. TÍNH TOÁN CÁC THÔNG SỐ TÀI CHÍNH
////        double shippingFee = 0.0;
////        double discountAmount = 0.0;
////        double finalTotalAmount = calculatedSubtotal - discountAmount + shippingFee;
////
////        newOrder.setSubtotal(calculatedSubtotal);
////        newOrder.setDiscountAmount(discountAmount);
////        newOrder.setShippingFee(shippingFee);
////        newOrder.setTotalAmount(finalTotalAmount);
////        newOrder.setStatus(OrderStatus.PENDING); // Sử dụng Enum trạng thái
////
////        // 5. LƯU ĐƠN HÀNG VÀ LÀM SẠCH GIỎ HÀNG
////        orderRepository.save(newOrder);
////        cart.getItems().clear();
////        cartRepository.save(cart);
////
////        return newOrder;
////    }
//    @Transactional(rollbackFor = Exception.class)
//    public Order processCheckout(nguoidung customer) {
//        // 1. KIỂM TRA GIỎ HÀNG KHÔNG ĐƯỢC TRỐNG
//        Cart cart = cartRepository.findByNguoidungId(customer.getId())
//                .orElseThrow(() -> new RuntimeException("Giỏ hàng của bạn không tồn tại!"));
//
//        if (cart.getItems() == null || cart.getItems().isEmpty()) {
//            throw new RuntimeException("Giỏ hàng đang trống, không thể tiến hành thanh toán!");
//        }
//
//        // 2. TẠO ĐƠN HÀNG MỚI VÀ SNAPSHOT ĐỊA CHỈ GIAO HÀNG
//        Order newOrder = new Order();
//        newOrder.setNguoidung(customer);
//
//        String shippingAddressSnapshot = (customer.getDc() != null && !customer.getDc().trim().isEmpty())
//                ? customer.getDc()
//                : "Địa chỉ mặc định của khách hàng";
//        newOrder.setShippingAddress(shippingAddressSnapshot);
//
//        // Đơn hàng khởi tạo ở trạng thái chờ thanh toán, KHÔNG PHẢI PAID
//        newOrder.setStatus(OrderStatus.PENDING);
//
//        double calculatedSubtotal = 0;
//
//        // 3. DUYỆT QUA TỪNG ITEM: KHÓA KHO, CHECK ACTIVE, CHECK STOCK & SNAPSHOT GIÁ
//        for (CartItem cartItem : cart.getItems()) {
//            Integer productId = cartItem.getSanpham().getId();
//            int quantityToBuy = cartItem.getQuantity();
//
//            // Sử dụng Khóa bi quan (Pessimistic Lock) để chống overselling
//            sanpham product = sanphamRepository.findByIdWithLock(productId)
//                    .orElseThrow(() -> new RuntimeException("Sản phẩm [" + cartItem.getSanpham().getTen() + "] không còn tồn tại!"));
//
//            // Kiểm tra sản phẩm còn active (ti == true) hay không
//            if (product.getTi() == null || !product.getTi()) {
//                throw new RuntimeException("Sản phẩm [" + product.getTen() + "] hiện đã ngừng kinh doanh.");
//            }
//
//            // Kiểm tra tồn kho khả dụng (Available = Stock - Reserve)
//            int availableQuantity = product.getStock() - (product.getReserve() != null ? product.getReserve() : 0);
//            if (availableQuantity < quantityToBuy) {
//                throw new RuntimeException("Sản phẩm [" + product.getTen() + "] không đủ số lượng tồn kho (Chỉ còn: " + availableQuantity + ").");
//            }
//
//            // Lấy giá hiện tại mới nhất từ Database
//            double currentUnitPrice = product.getGia();
//
//            // Trừ trực tiếp số lượng tồn kho tạm thời
//            product.setStock(product.getStock() - quantityToBuy);
//            sanphamRepository.save(product);
//
//            // Tạo OItem và khóa chặt (snapshot) giá tại thời điểm mua
//            OItem orderItem = new OItem();
//            orderItem.setOrder(newOrder);
//            orderItem.setSanpham(product);
//            orderItem.setQuantity(quantityToBuy);
//            orderItem.setUnitPrice(currentUnitPrice);
//
//            newOrder.getItems().add(orderItem);
//            calculatedSubtotal += (currentUnitPrice * quantityToBuy);
//        }
//
//        // 4. TÍNH TOÁN CÁC THÔNG SỐ TÀI CHÍNH
//        double shippingFee = 0.0;
//        double discountAmount = 0.0;
//        double finalTotalAmount = calculatedSubtotal - discountAmount + shippingFee;
//
//        newOrder.setSubtotal(calculatedSubtotal);
//        newOrder.setDiscountAmount(discountAmount);
//        newOrder.setShippingFee(shippingFee);
//        newOrder.setTotalAmount(finalTotalAmount);
//
//        // Lưu đơn hàng trước
//        Order savedOrder = orderRepository.save(newOrder);
//
//        // ==========================================
//        // 5. TẠO PAYMENT RECORD VỚI TRẠNG THÁI INITIATED
//        // ==========================================
//        /*
//        Payment payment = new Payment();
//        payment.setOrder(savedOrder);
//        payment.setAmount(finalTotalAmount);
//        payment.setStatus(PaymentStatus.INITIATED); // Trạng thái riêng biệt
//        paymentRepository.save(payment);
//        */
//
//        // 6. GỌI MOCK PAYMENT GATEWAY BÊN NGOÀI
//        boolean paymentSuccess = paymentGatewayService.processPayment(savedOrder.getId(), finalTotalAmount);
//
//        if (!paymentSuccess) {
//            // Nếu thanh toán FAILED -> Cập nhật payment thành FAILED (nếu có lưu entity payment)
//            // payment.setStatus(PaymentStatus.FAILED);
//            // paymentRepository.save(payment);
//
//            // Ném ngoại lệ để kích hoạt @Transactional Rollback:
//            // -> Hủy đơn hàng, hoàn trả lại tồn kho, đảm bảo không lưu trạng thái sai lệch.
//            throw new RuntimeException("Cổng thanh toán từ chối giao dịch (PAYMENT_FAILED). Đơn hàng đã bị hủy và hoàn trả tồn kho.");
//        }
//
//        // ==========================================
//        // 7. THANH TOÁN THÀNH CÔNG (SUCCESS)
//        // ==========================================
//        // payment.setStatus(PaymentStatus.SUCCESS);
//        // paymentRepository.save(payment);
//
//        // CHỈ KHI PAYMENT THÀNH CÔNG THÌ ORDER MỚI ĐƯỢC CHUYỂN SANG TRẠNG THÁI PAID / PROCESSING
//        savedOrder.setStatus(OrderStatus.PAID);
//        orderRepository.save(savedOrder);
//
//        // Làm sạch giỏ hàng sau khi mua thành công
//        cart.getItems().clear();
//        cartRepository.save(cart);
//
//        return savedOrder;
//    }
//    /**
//     * 4. Cập nhật trạng thái vòng đời đơn hàng (Lifecycle, RBAC & Hoàn kho tự động khi hủy)
//     */
////    @Transactional
////    public Order updateOrderStatus(Integer orderId, OrderStatus newStatus, nguoidung currentUser, String note) {
////        Order order = orderRepository.findById(orderId)
////                .orElseThrow(() -> new RuntimeException("Không tìm thấy đơn hàng #" + orderId));
////
////        OrderStatus currentStatus = order.getStatus();
////        boolean isAdmin = Boolean.TRUE.equals(currentUser.getVaitro());
////
////        // 1. KIỂM TRA PHÂN QUYỀN (CUSTOMER VS ADMIN)
////        if (isAdmin) {
////            // Khách hàng thông thường KHÔNG ĐƯỢC PHÉP tự ý chuyển trạng thái tùy tiện (ví dụ: tự chuyển sang PAID, SHIPPING...)
////            // Khách hàng chỉ được phép tự hủy đơn hàng của chính mình (nếu đơn ở trạng thái cho phép hủy)
////            if (newStatus == OrderStatus.CANCELLED) {
////                if (!order.getNguoidung().getId().equals(currentUser.getId())) {
////                    throw new RuntimeException("Bạn không có quyền hủy đơn hàng của người khác!");
////                }
////                if (!currentStatus.canCancel()) {
////                    throw new RuntimeException("Đơn hàng đang ở trạng thái [" + currentStatus.getDescription() + "], không thể hủy!");
////                }
////            } else {
////                throw new RuntimeException("Khách hàng không có quyền thay đổi trạng thái đơn hàng này!");
////            }
////        }
////
////        // 2. KIỂM TRA TÍNH HỢP LỆ CỦA LUỒNG TRẠNG THÁI (STATE TRANSITION VALIDATION)
////        // Ngăn chặn các trường hợp vô lý như: DELIVERED -> PENDING_PAYMENT hoặc CANCELLED -> SHIPPING
////        if (!currentStatus.canTransitionTo(newStatus)) {
////            throw new RuntimeException("Không thể chuyển trạng thái từ [" + currentStatus.getDescription() + "] sang [" + newStatus.getDescription() + "]!");
////        }
////
////        // 3. XỬ LÝ HOÀN KHO KHI HỦY ĐƠN (CANCELLED)
////        if (newStatus == OrderStatus.CANCELLED && currentStatus != OrderStatus.CANCELLED) {
////            for (OItem item : order.getItems()) {
////                sanpham product = sanphamRepository.findByIdWithLock(item.getSanpham().getId())
////                        .orElseThrow(() -> new RuntimeException("Sản phẩm không tồn tại!"));
////
////                // Hoàn lại tồn kho
////                product.setStock(product.getStock() + item.getQuantity());
////                sanphamRepository.save(product);
////            }
////        }
////
////        // 4. CẬP NHẬT TRẠNG THÁI MỚI
////        order.setStatus(newStatus);
////        return orderRepository.save(order);
////    }
////    @Transactional
////    public Order updateOrderStatus(Integer orderId, OrderStatus newStatus, nguoidung currentUser, String note) {
////        Order order = orderRepository.findById(orderId)
////                .orElseThrow(() -> new RuntimeException("Không tìm thấy đơn hàng #" + orderId));
////
////        OrderStatus currentStatus = order.getStatus();
////
////        // 1. KIỂM TRA BẢO MẬT: Bắt buộc phải có currentUser và phải là Admin (vaitro == true)
////        if (currentUser == null) {
////            throw new RuntimeException("Phiên đăng nhập đã hết hạn, vui lòng đăng nhập lại!");
////        }
////
////        boolean isAdmin = Boolean.TRUE.equals(currentUser.getVaitro());
////        if (isAdmin) {
////            throw new RuntimeException("Tài khoản [" + currentUser.getEmail() + "] không có quyền Admin!");
////        }
////
////        // 2. Nếu trạng thái không thay đổi -> Không làm gì cả
////        if (currentStatus == newStatus) {
////            return order;
////        }
////
////        // 3. Kiểm tra tính hợp lệ của luồng chuyển trạng thái (State Transition Rules)
////        if (!currentStatus.canTransitionTo(newStatus)) {
////            throw new RuntimeException("Không thể chuyển trạng thái từ [" + currentStatus.getDescription() + "] sang [" + newStatus.getDescription() + "]!");
////        }
////
////        // 4. Xử lý trường hợp HỦY ĐƠN HÀNG (CANCELLED) - Tự động hoàn trả tồn kho
////        if (newStatus == OrderStatus.CANCELLED && currentStatus != OrderStatus.CANCELLED) {
////            for (OItem item : order.getItems()) {
////                sanpham product = sanphamRepository.findByIdWithLock(item.getSanpham().getId())
////                        .orElseThrow(() -> new RuntimeException("Sản phẩm không tồn tại!"));
////
////                // Cộng lại kho thực tế
////                product.setStock(product.getStock() + item.getQuantity());
////                sanphamRepository.save(product);
////            }
////        }
////
////        // 5. Cập nhật trạng thái mới
////        order.setStatus(newStatus);
////        return orderRepository.save(order);
////    }
//    @Transactional
//    @CacheEvict(value = "productDetail", allEntries = true)
//    public void updateOrderStatus(Integer orderId, OrderStatus newStatus, nguoidung currentUser, String note) {
//        Order order = orderRepository.findById(orderId)
//                .orElseThrow(() -> new RuntimeException("Không tìm thấy đơn hàng!"));
//
//        OrderStatus oldStatus = order.getStatus();
//
//        // Cập nhật trạng thái mới cho đơn hàng
//        order.setStatus(newStatus);
//        orderRepository.save(order);
//
//        // CHỈ TRỪ KHO THỰC TẾ (STOCK) VÀ GIẢM RESERVE KHI ĐƠN HÀNG ĐÃ GIAO THÀNH CÔNG
//        // (Lưu ý: Thay OrderStatus.DELIVERED bằng đúng tên hằng số Enum "Đã giao thành công" của bạn)
//        if (oldStatus != OrderStatus.DELIVERED && newStatus == OrderStatus.DELIVERED) {
//            if (order.getItems() != null) {
//                for (OItem item : order.getItems()) {
//                    sanpham product = item.getSanpham();
//                    if (product != null) {
//                        int currentStock = product.getStock() != null ? product.getStock() : 0;
//                        int currentReserve = product.getReserve() != null ? product.getReserve() : 0;
//                        int quantity = item.getQuantity();
//
//                        // 1. Trừ tồn kho thực tế
//                        product.setStock(Math.max(0, currentStock - quantity));
//
//                        // 2. Giảm số lượng giữ chỗ (reserve) vì hàng đã giao thành công
//                        product.setReserve(Math.max(0, currentReserve - quantity));
//
//                        sanphamRepository.save(product);
//                    }
//                }
//            }
//        }
//    }
//    @Transactional(rollbackFor = Exception.class)
//    public Order retryPayment(Integer orderId, nguoidung customer) {
//        // 1. Tìm đơn hàng theo ID
//        Order order = orderRepository.findById(orderId)
//                .orElseThrow(() -> new RuntimeException("Không tìm thấy đơn hàng #" + orderId));
//
//        // 2. Kiểm tra bảo mật: Đơn hàng có thuộc về khách hàng đang đăng nhập hay không?
//        if (order.getNguoidung() == null || !order.getNguoidung().getId().equals(customer.getId())) {
//            throw new RuntimeException("Bạn không có quyền thao tác trên đơn hàng này!");
//        }
//
//        // 3. Kiểm tra trạng thái đơn hàng có phù hợp để retry hay không (Phải là PENDING_PAYMENT)
//        if (order.getStatus() != OrderStatus.PENDING) {
//            throw new RuntimeException("Đơn hàng này không ở trạng thái chờ thanh toán, không thể thanh toán lại!");
//        }
//
//        // 4. (Tùy chọn) Lưu lịch sử giao dịch thanh toán mới hoặc cập nhật trạng thái payment record cũ thành INITIATED
//
//        // 5. Gọi lại Mock Payment Gateway với số tiền của đơn hàng cũ
//        boolean paymentSuccess = paymentGatewayService.processPayment(order.getId(), order.getTotalAmount());
//
//        if (!paymentSuccess) {
//            // Thanh toán lại vẫn thất bại -> Giữ nguyên trạng thái PENDING_PAYMENT
//            // Kho hàng được giữ nguyên, khách có thể bấm retry tiếp tục sau đó.
//            throw new RuntimeException("Cổng thanh toán từ chối giao dịch (PAYMENT_FAILED). Vui lòng thử lại sau.");
//        }
//
//        // 6. THANH TOÁN THÀNH CÔNG -> Cập nhật trạng thái đơn hàng sang PAID
//        order.setStatus(OrderStatus.PAID);
//        orderRepository.save(order);
//
//        // 7. Dọn sạch giỏ hàng (nếu trước đó giỏ hàng chưa bị clear ở bước checkout lỗi)
//        cartRepository.findByNguoidungId(customer.getId()).ifPresent(cart -> {
//            if (cart.getItems() != null && !cart.getItems().isEmpty()) {
//                cart.getItems().clear();
//                cartRepository.save(cart);
//            }
//        });
//
//        return order;
//    }
//    @Transactional(rollbackFor = Exception.class)
//    public Order processBuyNow(nguoidung customer, Integer productId, int quantityToBuy) {
//        // 1. Tạo đơn hàng mới
//        Order newOrder = new Order();
//        newOrder.setNguoidung(customer);
//
//        String shippingAddressSnapshot = (customer.getDc() != null && !customer.getDc().trim().isEmpty())
//                ? customer.getDc()
//                : "Địa chỉ mặc định của khách hàng";
//        newOrder.setShippingAddress(shippingAddressSnapshot);
//        newOrder.setStatus(OrderStatus.PENDING);
//
//        // 2. Khóa kho sản phẩm bằng Pessimistic Lock chống overselling
//        sanpham product = sanphamRepository.findByIdWithLock(productId)
//                .orElseThrow(() -> new RuntimeException("Sản phẩm không còn tồn tại trong hệ thống!"));
//
//        // Kiểm tra ngừng kinh doanh
//        if (product.getTi() == null || !product.getTi()) {
//            throw new RuntimeException("Sản phẩm [" + product.getTen() + "] hiện đã ngừng kinh doanh.");
//        }
//
//        // Kiểm tra tồn kho khả dụng
//        int availableQuantity = product.getStock() - (product.getReserve() != null ? product.getReserve() : 0);
//        if (availableQuantity < quantityToBuy) {
//            throw new RuntimeException("Sản phẩm không đủ số lượng tồn kho (Chỉ còn: " + availableQuantity + ").");
//        }
//
//        double currentUnitPrice = product.getGia();
//
//        // Trừ trực tiếp tồn kho tạm thời
//        product.setStock(product.getStock() - quantityToBuy);
//        sanphamRepository.save(product);
//
//        // Tạo OItem snapshot giá
//        OItem orderItem = new OItem();
//        orderItem.setOrder(newOrder);
//        orderItem.setSanpham(product);
//        orderItem.setQuantity(quantityToBuy);
//        orderItem.setUnitPrice(currentUnitPrice);
//
//        newOrder.getItems().add(orderItem);
//
//        // 3. Tính toán tài chính
//        double subtotal = currentUnitPrice * quantityToBuy;
//        double shippingFee = 30000.0; // Phí ship mẫu
//        double totalAmount = subtotal + shippingFee;
//
//        newOrder.setSubtotal(subtotal);
//        newOrder.setDiscountAmount(0.0);
//        newOrder.setShippingFee(shippingFee);
//        newOrder.setTotalAmount(totalAmount);
//
//        Order savedOrder = orderRepository.save(newOrder);
//
//        // 4. Tạo bản ghi Payment với trạng thái INITIATED
//        payment paymentRecord = new payment();
//        paymentRecord.setOrder(savedOrder);
//        paymentRecord.setAmount(totalAmount);
//        paymentRecord.setStatus(PaymentStatus.INITIATED);
//        paymentRepository.save(paymentRecord);
//
//        // 5. Gọi Mock Payment Gateway
//        boolean paymentSuccess = paymentGatewayService.processPayment(savedOrder.getId(), totalAmount);
//
//        if (!paymentSuccess) {
//            // Thanh toán thất bại -> Cập nhật payment thành FAILED và ném ngoại lệ kích hoạt Rollback kho
//            paymentRecord.setStatus(PaymentStatus.FAILED);
//            paymentRepository.save(paymentRecord);
//            throw new RuntimeException("Cổng thanh toán từ chối giao dịch (PAYMENT_FAILED). Đã hủy đơn và hoàn trả kho.");
//        }
//
//        // 6. Thanh toán thành công -> Cập nhật trạng thái Payment và Order
//        paymentRecord.setStatus(PaymentStatus.SUCCESS);
//        paymentRecord.setTransactionCode("TXN-" + System.currentTimeMillis());
//        paymentRepository.save(paymentRecord);
//
//        savedOrder.setStatus(OrderStatus.PAID);
//        return orderRepository.save(savedOrder);
//    }
//    @Transactional(rollbackFor = Exception.class)
//    public Order processBuyNowOrder(nguoidung customer, Integer productId, int quantityToBuy) {
//
//        // 1. Khởi tạo đơn hàng mới cho khách hàng
//        Order newOrder = new Order();
//        newOrder.setNguoidung(customer);
//
//        // Lấy địa chỉ của khách làm snapshot, nếu trống dùng địa chỉ mặc định
//        String shippingAddressSnapshot = (customer.getDc() != null && !customer.getDc().trim().isEmpty())
//                ? customer.getDc()
//                : "Địa chỉ mặc định của khách hàng";
//        newOrder.setShippingAddress(shippingAddressSnapshot);
//
//        // Trạng thái ban đầu của đơn hàng là chờ thanh toán
//        newOrder.setStatus(OrderStatus.PENDING);
//
//        // 2. Khóa kho sản phẩm bằng Pessimistic Lock (chống overselling khi nhiều người mua cùng lúc)
//        sanpham product = sanphamRepository.findByIdWithLock(productId)
//                .orElseThrow(() -> new RuntimeException("Sản phẩm không còn tồn tại trong hệ thống!"));
//
//        // Kiểm tra xem sản phẩm có đang kinh doanh hay không
//        if (product.getTi() == null || !product.getTi()) {
//            throw new RuntimeException("Sản phẩm [" + product.getTen() + "] hiện đã ngừng kinh doanh.");
//        }
//
//        // Tính tồn kho khả dụng thực tế (Stock - Reserve)
//        int availableQuantity = product.getStock() - (product.getReserve() != null ? product.getReserve() : 0);
//        if (availableQuantity < quantityToBuy) {
//            throw new RuntimeException("Sản phẩm không đủ số lượng tồn kho (Chỉ còn lại: " + availableQuantity + " sản phẩm).");
//        }
//
//        double currentUnitPrice = product.getGia();
//
//        // Tiến hành trừ kho tạm thời
//        product.setStock(product.getStock() - quantityToBuy);
//        sanphamRepository.save(product);
//
//        // 3. Tạo Order Item (OItem) lưu snapshot giá tại thời điểm mua
//        OItem orderItem = new OItem();
//        orderItem.setOrder(newOrder);
//        orderItem.setSanpham(product);
//        orderItem.setQuantity(quantityToBuy);
//        orderItem.setUnitPrice(currentUnitPrice);
//
//        newOrder.getItems().add(orderItem);
//
//        // 4. Tính toán các khoản chi phí
//        double subtotal = currentUnitPrice * quantityToBuy;
//        double shippingFee = 30000.0; // Phí vận chuyển mẫu cố định
//        double totalAmount = subtotal + shippingFee;
//
//        newOrder.setSubtotal(subtotal);
//        newOrder.setDiscountAmount(0.0);
//        newOrder.setShippingFee(shippingFee);
//        newOrder.setTotalAmount(totalAmount);
//
//        // LƯU ĐƠN HÀNG XUỐNG DATABASE TRƯỚC TIÊN (Đảm bảo có ID đơn hàng cho Payment & Retry)
//        Order savedOrder = orderRepository.save(newOrder);
//
//        // 5. Tạo bản ghi Payment khởi tạo (INITIATED) gắn với đơn hàng
//        payment paymentRecord = new payment();
//        paymentRecord.setOrder(savedOrder);
//        paymentRecord.setAmount(totalAmount);
//        paymentRecord.setStatus(PaymentStatus.INITIATED);
//        paymentRepository.save(paymentRecord);
//
//        // 6. Gọi Mock Payment Gateway giả lập giao dịch thanh toán
//        boolean paymentSuccess = paymentGatewayService.processPayment(savedOrder.getId(), totalAmount);
//
//        if (!paymentSuccess) {
//            // Trường hợp thanh toán THẤT BẠI từ cổng thanh toán:
//            // Cập nhật trạng thái payment thành FAILED, KHÔNG THROW EXCEPTION để giữ lại đơn hàng.
//            paymentRecord.setStatus(PaymentStatus.FAILED);
//            paymentRepository.save(paymentRecord);
//
//            // Đơn hàng giữ nguyên trạng thái PENDING_PAYMENT, khách hàng có thể bấm "Thanh toán lại" (Retry).
//            return savedOrder;
//        }
//
//        // 7. Trường hợp thanh toán THÀNH CÔNG (SUCCESS)
//        paymentRecord.setStatus(PaymentStatus.SUCCESS);
//        paymentRecord.setTransactionCode("TXN-BUYNOW-" + System.currentTimeMillis());
//        paymentRepository.save(paymentRecord);
//
//        // Cập nhật trạng thái đơn hàng sang PAID
//        savedOrder.setStatus(OrderStatus.PAID);
//        return orderRepository.save(savedOrder);
//    }
//    @Transactional
//    public Order processCheckoutWithDetails(nguoidung customer,
//                                            Cart cart,
//                                            double subtotal,
//                                            double shippingFee,
//                                            double discountAmount,
//                                            double totalAmount,
//                                            String couponCode) {
//
//        // 1. Khởi tạo Order Entity mới
//        Order order = new Order();
//        order.setNguoidung(customer);
//        order.setShippingAddress(customer.getDc() != null ? customer.getDc() : "Địa chỉ mặc định");
//        order.setSubtotal(subtotal);
//        order.setShippingFee(shippingFee);
//        order.setDiscountAmount(discountAmount);
//        order.setTotalAmount(totalAmount);
//        order.setCouponCode(couponCode);
//        order.setStatus(OrderStatus.PAID); // Hoặc PENDING tùy theo luồng thanh toán của bạn
//        order.setCreatedAt(LocalDateTime.now());
//
//        // 2. Chuyển đổi các mục từ giỏ hàng (CartItem) sang chi tiết đơn hàng (OItem) và trừ kho
//        List<OItem> orderItems = new ArrayList<>();
//
//        for (CartItem cartItem : cart.getItems()) {
//            sanpham product = cartItem.getSanpham();
//            int buyQuantity = cartItem.getQuantity();
//
//            // Kiểm tra tồn kho trước khi trừ
//            if (product.getStock() < buyQuantity) {
//                throw new RuntimeException("Sản phẩm '" + product.getTen() + "' không đủ số lượng trong kho!");
//            }
//
//            // Trừ số lượng tồn kho sản phẩm
//            product.setStock(product.getStock() - buyQuantity);
//            sanphamRepository.save(product);
//
//            // Tạo OItem gắn vào Order
//            OItem oItem = new OItem();
//            oItem.setOrder(order);
//            oItem.setSanpham(product);
//            oItem.setQuantity(buyQuantity);
//            oItem.setUnitPrice(product.getGia()); // Lưu lại đơn giá tại thời điểm mua
//
//            orderItems.add(oItem);
//        }
//
//        order.setItems(orderItems);
//
//        // 3. Lưu Order xuống CSDL (CascadeType.ALL sẽ tự động lưu danh sách OItem)
//        Order savedOrder = orderRepository.save(order);
//
//        // 4. Dọn dẹp/xóa giỏ hàng sau khi đặt hàng thành công
//        cart.getItems().clear(); // Xóa sạch các item trong giỏ
//        cartRepository.save(cart); // Cập nhật lại giỏ hàng rỗng trong DB
//
//        return savedOrder;
//    }
//}
package com.example.ttap.service;

import com.example.ttap.entity.*;
import com.example.ttap.repository.CartRepository;
import com.example.ttap.repository.PaymentRepository;
import com.example.ttap.repository.orderre;
import com.example.ttap.repository.sphamre;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class OrderService {

    @Autowired
    private sphamre sanphamRepository;

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private orderre orderRepository;

    @Autowired
    PaymentService paymentGatewayService;

    @Autowired
    PaymentRepository paymentRepository;

    /**
     * Phương thức tạo đơn hàng cơ bản từ giỏ hàng (Chỉ giữ chỗ - Reserve, KHÔNG TRỪ STOCK)
     */
    @Transactional
    public Order createOrderFromCart(nguoidung customer) {
        Cart cart = cartRepository.findByNguoidungId(customer.getId())
                .orElseThrow(() -> new RuntimeException("Giỏ hàng trống!"));

        if (cart.getItems() == null || cart.getItems().isEmpty()) {
            throw new RuntimeException("Không có sản phẩm nào trong giỏ hàng để thanh toán!");
        }

        Order newOrder = new Order();
        newOrder.setNguoidung(customer);
        double totalOrderAmount = 0;

        for (CartItem cartItem : cart.getItems()) {
            Integer productId = cartItem.getSanpham().getId();
            int quantityToBuy = cartItem.getQuantity();

            sanpham product = sanphamRepository.findByIdWithLock(productId)
                    .orElseThrow(() -> new RuntimeException("Sản phẩm " + cartItem.getSanpham().getTen() + " không tồn tại!"));

            // Kiểm tra tồn kho khả dụng (Available = Stock - Reserve)
            int currentStock = product.getStock() != null ? product.getStock() : 0;
            int currentReserve = product.getReserve() != null ? product.getReserve() : 0;
            int available = currentStock - currentReserve;

            if (available < quantityToBuy) {
                throw new RuntimeException("Sản phẩm [" + product.getTen() + "] không đủ số lượng khả dụng!");
            }

            double currentUnitPrice = product.getGia();

            // CHỈ TĂNG RESERVE (GIỮ CHỖ), KHÔNG ĐỤNG ĐẾN STOCK
            product.setReserve(currentReserve + quantityToBuy);
            sanphamRepository.save(product);

            OItem orderItem = new OItem();
            orderItem.setOrder(newOrder);
            orderItem.setSanpham(product);
            orderItem.setQuantity(quantityToBuy);
            orderItem.setUnitPrice(currentUnitPrice);

            newOrder.getItems().add(orderItem);
            totalOrderAmount += (currentUnitPrice * quantityToBuy);
        }

        newOrder.setSubtotal(totalOrderAmount);
        newOrder.setTotalAmount(totalOrderAmount);
        newOrder.setStatus(OrderStatus.PENDING);

        orderRepository.save(newOrder);

        cart.getItems().clear();
        cartRepository.save(cart);

        return newOrder;
    }

    /**
     * Phương thức Process Checkout đầy đủ (Chỉ giữ chỗ - Reserve, KHÔNG TRỪ STOCK)
     */
    @Transactional(rollbackFor = Exception.class)
    public Order processCheckout(nguoidung customer) {
        Cart cart = cartRepository.findByNguoidungId(customer.getId())
                .orElseThrow(() -> new RuntimeException("Giỏ hàng của bạn không tồn tại!"));

        if (cart.getItems() == null || cart.getItems().isEmpty()) {
            throw new RuntimeException("Giỏ hàng đang trống, không thể tiến hành thanh toán!");
        }

        Order newOrder = new Order();
        newOrder.setNguoidung(customer);

        String shippingAddressSnapshot = (customer.getDc() != null && !customer.getDc().trim().isEmpty())
                ? customer.getDc()
                : "Địa chỉ mặc định của khách hàng";
        newOrder.setShippingAddress(shippingAddressSnapshot);
        newOrder.setStatus(OrderStatus.PENDING);

        double calculatedSubtotal = 0;

        for (CartItem cartItem : cart.getItems()) {
            Integer productId = cartItem.getSanpham().getId();
            int quantityToBuy = cartItem.getQuantity();

            sanpham product = sanphamRepository.findByIdWithLock(productId)
                    .orElseThrow(() -> new RuntimeException("Sản phẩm [" + cartItem.getSanpham().getTen() + "] không còn tồn tại!"));

            if (product.getTi() == null || !product.getTi()) {
                throw new RuntimeException("Sản phẩm [" + product.getTen() + "] hiện đã ngừng kinh doanh.");
            }

            int currentStock = product.getStock() != null ? product.getStock() : 0;
            int currentReserve = product.getReserve() != null ? product.getReserve() : 0;
            int availableQuantity = currentStock - currentReserve;

            if (availableQuantity < quantityToBuy) {
                throw new RuntimeException("Sản phẩm [" + product.getTen() + "] không đủ số lượng tồn kho (Chỉ còn: " + availableQuantity + ").");
            }

            double currentUnitPrice = product.getGia();

            // CHỈ TĂNG RESERVE (GIỮ CHỖ), KHÔNG TRỪ STOCK
            product.setReserve(currentReserve + quantityToBuy);
            sanphamRepository.save(product);

            OItem orderItem = new OItem();
            orderItem.setOrder(newOrder);
            orderItem.setSanpham(product);
            orderItem.setQuantity(quantityToBuy);
            orderItem.setUnitPrice(currentUnitPrice);

            newOrder.getItems().add(orderItem);
            calculatedSubtotal += (currentUnitPrice * quantityToBuy);
        }

        double shippingFee = 0.0;
        double discountAmount = 0.0;
        double finalTotalAmount = calculatedSubtotal - discountAmount + shippingFee;

        newOrder.setSubtotal(calculatedSubtotal);
        newOrder.setDiscountAmount(discountAmount);
        newOrder.setShippingFee(shippingFee);
        newOrder.setTotalAmount(finalTotalAmount);

        Order savedOrder = orderRepository.save(newOrder);

        boolean paymentSuccess = paymentGatewayService.processPayment(savedOrder.getId(), finalTotalAmount);

        if (!paymentSuccess) {
            // NẾU THANH TOÁN THẤT BẠI -> HOÀN TRẢ LẠI RESERVE ĐÃ GIỮ CHỖ
            for (OItem item : savedOrder.getItems()) {
                sanpham product = sanphamRepository.findByIdWithLock(item.getSanpham().getId()).orElse(null);
                if (product != null) {
                    int curRes = product.getReserve() != null ? product.getReserve() : 0;
                    product.setReserve(Math.max(0, curRes - item.getQuantity()));
                    sanphamRepository.save(product);
                }
            }
            throw new RuntimeException("Cổng thanh toán từ chối giao dịch (PAYMENT_FAILED). Đơn hàng đã bị hủy và hoàn trả giữ chỗ.");
        }

        savedOrder.setStatus(OrderStatus.PAID);
        orderRepository.save(savedOrder);

        cart.getItems().clear();
        cartRepository.save(cart);

        return savedOrder;
    }

    /**
     * Cập nhật trạng thái đơn hàng: CHỈ TRỪ STOCK KHI ĐẠT TRẠNG THÁI DELIVERED (Đã giao thành công)
     */
    @Transactional
    @CacheEvict(value = "productDetail", allEntries = true)
    public void updateOrderStatus(Integer orderId, OrderStatus newStatus, nguoidung currentUser, String note) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy đơn hàng!"));

        OrderStatus oldStatus = order.getStatus();

        // 1. NẾU ĐƠN HÀNG BỊ HỦY (CANCELLED) VÀ TRƯỚC ĐÓ CHƯA BỊ HỦY -> HOÀN TRẢ RESERVE
        if (newStatus == OrderStatus.CANCELLED && oldStatus != OrderStatus.CANCELLED) {
            if (order.getItems() != null) {
                for (OItem item : order.getItems()) {
                    sanpham product = sanphamRepository.findByIdWithLock(item.getSanpham().getId()).orElse(null);
                    if (product != null) {
                        int currentReserve = product.getReserve() != null ? product.getReserve() : 0;
                        product.setReserve(Math.max(0, currentReserve - item.getQuantity()));
                        sanphamRepository.save(product);
                    }
                }
            }
        }

        // 2. Cập nhật trạng thái mới cho đơn hàng
        order.setStatus(newStatus);
        orderRepository.save(order);
        // 3. CHỈ TRỪ KHO THỰC TẾ (STOCK) VÀ GIẢM RESERVE KHI ĐƠN HÀNG CHUYỂN SANG "DELIVERED" (Đã giao hàng thành công)
        if (oldStatus != OrderStatus.DELIVERED && newStatus == OrderStatus.DELIVERED) {
            if (order.getItems() != null) {
                for (OItem item : order.getItems()) {
                    sanpham product = sanphamRepository.findByIdWithLock(item.getSanpham().getId()).orElse(null);
                    if (product != null) {
                        int currentStock = product.getStock() != null ? product.getStock() : 0;
                        int currentReserve = product.getReserve() != null ? product.getReserve() : 0;
                        int quantity = item.getQuantity();

                        // Trừ tồn kho thực tế (stock)
                        product.setStock(Math.max(0, currentStock - quantity));

                        // Giảm số lượng giữ chỗ (reserve) vì hàng đã giao thành công ra khỏi kho
                        product.setReserve(Math.max(0, currentReserve - quantity));

                        sanphamRepository.save(product);
                    }
                }
            }
        }
    }
    @Transactional
    @Caching(evict = {
            @CacheEvict(value = "productDetail", allEntries = true),
            @CacheEvict(value = "products", allEntries = true),
            @CacheEvict(value = "tonkho", allEntries = true)
    })
    public void updateOrderStatusByAdmin(Integer orderId, OrderStatus newStatus, nguoidung currentUser, String note) {
        if (currentUser == null) {
            throw new IllegalStateException("Vui lòng đăng nhập!");
        }

        // Kiểm tra quyền Admin (sửa lại điều kiện này theo đúng quy ước getVaitro() của bạn)
        boolean isAdmin = Boolean.TRUE.equals(currentUser.getVaitro());
        if (isAdmin) {
            throw new IllegalStateException("Chỉ tài khoản Admin mới có quyền cập nhật trạng thái đơn hàng tại đây!");
        }

        if (newStatus == null) {
            throw new IllegalArgumentException("Trạng thái mới không hợp lệ!");
        }

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy đơn hàng!"));

        OrderStatus oldStatus = order.getStatus();
        if (oldStatus == newStatus) {
            return;
        }

        // Kiểm tra ma trận chuyển đổi trạng thái hợp lệ (chặn DELIVERED -> PENDING_PAYMENT, CANCELLED -> SHIPPING, v.v.)
        if (oldStatus == null || !oldStatus.canTransitionTo(newStatus)) {
            throw new IllegalStateException("Không thể chuyển trạng thái từ " + oldStatus + " sang " + newStatus);
        }

        // Thực hiện cập nhật kho & lưu trạng thái
        applyStatusChangeAndInventory(order, oldStatus, newStatus, note);
    }
    private void applyStatusChangeAndInventory(Order order, OrderStatus oldStatus, OrderStatus newStatus, String note) {
        // 1. Chuyển sang CANCELLED -> hoàn trả reserve
        if (newStatus == OrderStatus.CANCELLED && oldStatus != OrderStatus.CANCELLED) {
            if (order.getItems() != null) {
                for (OItem item : order.getItems()) {
                    sanpham product = sanphamRepository.findByIdWithLock(item.getSanpham().getId()).orElse(null);
                    if (product != null) {
                        int currentReserve = product.getReserve() != null ? product.getReserve() : 0;
                        product.setReserve(Math.max(0, currentReserve - item.getQuantity()));
                        sanphamRepository.save(product);
                    }
                }
            }
        }

        // 2. Lưu trạng thái mới
        order.setStatus(newStatus);
        if (note != null && !note.isBlank()) {
            // Nếu entity Order có trường ghi chú thì gán thêm ở đây
        }
        orderRepository.save(order);

        // 3. Chuyển sang DELIVERED -> trừ stock và giảm reserve
        if (oldStatus != OrderStatus.DELIVERED && newStatus == OrderStatus.DELIVERED) {
            if (order.getItems() != null) {
                for (OItem item : order.getItems()) {
                    sanpham product = sanphamRepository.findByIdWithLock(item.getSanpham().getId()).orElse(null);
                    if (product != null) {
                        int currentStock = product.getStock() != null ? product.getStock() : 0;
                        int currentReserve = product.getReserve() != null ? product.getReserve() : 0;
                        int quantity = item.getQuantity();

                        product.setStock(Math.max(0, currentStock - quantity));
                        product.setReserve(Math.max(0, currentReserve - quantity));
                        sanphamRepository.save(product);
                    }
                }
            }
        }
    }
    @Transactional(rollbackFor = Exception.class)
    public Order retryPayment(Integer orderId, nguoidung customer) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy đơn hàng #" + orderId));

        if (order.getNguoidung() == null || !order.getNguoidung().getId().equals(customer.getId())) {
            throw new RuntimeException("Bạn không có quyền thao tác trên đơn hàng này!");
        }

        if (order.getStatus() != OrderStatus.PENDING) {
            throw new RuntimeException("Đơn hàng này không ở trạng thái chờ thanh toán, không thể thanh toán lại!");
        }

        boolean paymentSuccess = paymentGatewayService.processPayment(order.getId(), order.getTotalAmount());

        if (!paymentSuccess) {
            throw new RuntimeException("Cổng thanh toán từ chối giao dịch (PAYMENT_FAILED). Vui lòng thử lại sau.");
        }

        order.setStatus(OrderStatus.PAID);
        orderRepository.save(order);

        cartRepository.findByNguoidungId(customer.getId()).ifPresent(cart -> {
            if (cart.getItems() != null && !cart.getItems().isEmpty()) {
                cart.getItems().clear();
                cartRepository.save(cart);
            }
        });

        return order;
    }
    /**
     * Mua ngay (Buy Now) - Chỉ tăng reserve, không trừ stock
     */
    @Transactional(rollbackFor = Exception.class)
    public Order processBuyNow(nguoidung customer, Integer productId, int quantityToBuy) {
        Order newOrder = new Order();
        newOrder.setNguoidung(customer);

        String shippingAddressSnapshot = (customer.getDc() != null && !customer.getDc().trim().isEmpty())
                ? customer.getDc()
                : "Địa chỉ mặc định của khách hàng";
        newOrder.setShippingAddress(shippingAddressSnapshot);
        newOrder.setStatus(OrderStatus.PENDING);

        sanpham product = sanphamRepository.findByIdWithLock(productId)
                .orElseThrow(() -> new RuntimeException("Sản phẩm không còn tồn tại trong hệ thống!"));

        if (product.getTi() == null || !product.getTi()) {
            throw new RuntimeException("Sản phẩm [" + product.getTen() + "] hiện đã ngừng kinh doanh.");
        }

        int currentStock = product.getStock() != null ? product.getStock() : 0;
        int currentReserve = product.getReserve() != null ? product.getReserve() : 0;
        int availableQuantity = currentStock - currentReserve;

        if (availableQuantity < quantityToBuy) {
            throw new RuntimeException("Sản phẩm không đủ số lượng tồn kho khả dụng (Chỉ còn: " + availableQuantity + ").");
        }

        double currentUnitPrice = product.getGia();

        // CHỈ TĂNG RESERVE, KHÔNG TRỪ STOCK
        product.setReserve(currentReserve + quantityToBuy);
        sanphamRepository.save(product);

        OItem orderItem = new OItem();
        orderItem.setOrder(newOrder);
        orderItem.setSanpham(product);
        orderItem.setQuantity(quantityToBuy);
        orderItem.setUnitPrice(currentUnitPrice);

        newOrder.getItems().add(orderItem);

        double subtotal = currentUnitPrice * quantityToBuy;
        double shippingFee = 30000.0;
        double totalAmount = subtotal + shippingFee;

        newOrder.setSubtotal(subtotal);
        newOrder.setDiscountAmount(0.0);
        newOrder.setShippingFee(shippingFee);
        newOrder.setTotalAmount(totalAmount);

        Order savedOrder = orderRepository.save(newOrder);

        payment paymentRecord = new payment();
        paymentRecord.setOrder(savedOrder);
        paymentRecord.setAmount(totalAmount);
        paymentRecord.setStatus(PaymentStatus.INITIATED);
        paymentRepository.save(paymentRecord);

        boolean paymentSuccess = paymentGatewayService.processPayment(savedOrder.getId(), totalAmount);

        if (!paymentSuccess) {
            paymentRecord.setStatus(PaymentStatus.FAILED);
            paymentRepository.save(paymentRecord);

            // Hoàn lại reserve khi thanh toán BuyNow thất bại
            product.setReserve(Math.max(0, product.getReserve() - quantityToBuy));
            sanphamRepository.save(product);

            throw new RuntimeException("Cổng thanh toán từ chối giao dịch (PAYMENT_FAILED). Đã hủy đơn và hoàn trả giữ chỗ.");
        }

        paymentRecord.setStatus(PaymentStatus.SUCCESS);
        paymentRecord.setTransactionCode("TXN-" + System.currentTimeMillis());
        paymentRepository.save(paymentRecord);

        savedOrder.setStatus(OrderStatus.PAID);
        return orderRepository.save(savedOrder);
    }

    @Transactional(rollbackFor = Exception.class)
    public Order processBuyNowOrder(nguoidung customer, Integer productId, int quantityToBuy) {
        Order newOrder = new Order();
        newOrder.setNguoidung(customer);

        String shippingAddressSnapshot = (customer.getDc() != null && !customer.getDc().trim().isEmpty())
                ? customer.getDc()
                : "Địa chỉ mặc định của khách hàng";
        newOrder.setShippingAddress(shippingAddressSnapshot);
        newOrder.setStatus(OrderStatus.PENDING);

        sanpham product = sanphamRepository.findByIdWithLock(productId)
                .orElseThrow(() -> new RuntimeException("Sản phẩm không còn tồn tại trong hệ thống!"));

        if (product.getTi() == null || !product.getTi()) {
            throw new RuntimeException("Sản phẩm [" + product.getTen() + "] hiện đã ngừng kinh doanh.");
        }

        int currentStock = product.getStock() != null ? product.getStock() : 0;
        int currentReserve = product.getReserve() != null ? product.getReserve() : 0;
        int availableQuantity = currentStock - currentReserve;

        if (availableQuantity < quantityToBuy) {
            throw new RuntimeException("Sản phẩm không đủ số lượng tồn kho (Chỉ còn lại: " + availableQuantity + " sản phẩm).");
        }

        double currentUnitPrice = product.getGia();

        // CHỈ TĂNG RESERVE, KHÔNG TRỪ STOCK
        product.setReserve(currentReserve + quantityToBuy);
        sanphamRepository.save(product);

        OItem orderItem = new OItem();
        orderItem.setOrder(newOrder);
        orderItem.setSanpham(product);
        orderItem.setQuantity(quantityToBuy);
        orderItem.setUnitPrice(currentUnitPrice);

        newOrder.getItems().add(orderItem);

        double subtotal = currentUnitPrice * quantityToBuy;
        double shippingFee = 30000.0;
        double totalAmount = subtotal + shippingFee;

        newOrder.setSubtotal(subtotal);
        newOrder.setDiscountAmount(0.0);
        newOrder.setShippingFee(shippingFee);
        newOrder.setTotalAmount(totalAmount);

        Order savedOrder = orderRepository.save(newOrder);

        payment paymentRecord = new payment();
        paymentRecord.setOrder(savedOrder);
        paymentRecord.setAmount(totalAmount);
        paymentRecord.setStatus(PaymentStatus.INITIATED);
        paymentRepository.save(paymentRecord);

        boolean paymentSuccess = paymentGatewayService.processPayment(savedOrder.getId(), totalAmount);

        if (!paymentSuccess) {
            paymentRecord.setStatus(PaymentStatus.FAILED);
            paymentRepository.save(paymentRecord);
            return savedOrder;
        }

        paymentRecord.setStatus(PaymentStatus.SUCCESS);
        paymentRecord.setTransactionCode("TXN-BUYNOW-" + System.currentTimeMillis());
        paymentRepository.save(paymentRecord);

        savedOrder.setStatus(OrderStatus.PAID);
        return orderRepository.save(savedOrder);
    }

    @Transactional
    public Order processCheckoutWithDetails(nguoidung customer,
                                            Cart cart,
                                            double subtotal,
                                            double shippingFee,
                                            double discountAmount,
                                            double totalAmount,
                                            String couponCode) {

        Order order = new Order();
        order.setNguoidung(customer);
        order.setShippingAddress(customer.getDc() != null ? customer.getDc() : "Địa chỉ mặc định");
        order.setSubtotal(subtotal);
        order.setShippingFee(shippingFee);
        order.setDiscountAmount(discountAmount);
        order.setTotalAmount(totalAmount);
        order.setCouponCode(couponCode);
        order.setStatus(OrderStatus.PENDING);
        order.setCreatedAt(LocalDateTime.now());

        List<OItem> orderItems = new ArrayList<>();

        for (CartItem cartItem : cart.getItems()) {
            sanpham product = cartItem.getSanpham();
            int buyQuantity = cartItem.getQuantity();

            int currentStock = product.getStock() != null ? product.getStock() : 0;
            int currentReserve = product.getReserve() != null ? product.getReserve() : 0;
            int available = currentStock - currentReserve;

//            if (available < buyQuantity) {
//                throw new RuntimeException("Sản phẩm '" + product.getTen() + "' không đủ số lượng khả dụng trong kho!");
//            }

            // CHỈ TĂNG RESERVE, KHÔNG TRỪ STOCK
            product.setReserve(buyQuantity);
            sanphamRepository.save(product);

            OItem oItem = new OItem();
            oItem.setOrder(order);
            oItem.setSanpham(product);
            oItem.setQuantity(buyQuantity);
            oItem.setUnitPrice(product.getGia());

            orderItems.add(oItem);
        }

        order.setItems(orderItems);

        Order savedOrder = orderRepository.save(order);

        cart.getItems().clear();
        cartRepository.save(cart);

        return savedOrder;
    }
//@Transactional
//public Order processCheckoutWithDetails(nguoidung customer,
//                                        Cart cart,
//                                        double subtotal,
//                                        double shippingFee,
//                                        double discountAmount,
//                                        double totalAmount,
//                                        String couponCode) {
//
//    Order order = new Order();
//    order.setNguoidung(customer);
//    order.setShippingAddress(customer.getDc() != null ? customer.getDc() : "Địa chỉ mặc định");
//    order.setSubtotal(subtotal);
//    order.setShippingFee(shippingFee);
//    order.setDiscountAmount(discountAmount); // Lưu tiền giảm giá vào DB
//    order.setTotalAmount(totalAmount);       // Lưu tổng tiền đã trừ discount vào DB
//    order.setCouponCode(couponCode);         // Lưu mã giảm giá vào DB
//    order.setStatus(OrderStatus.PENDING);
//    order.setCreatedAt(LocalDateTime.now());
//
//    // ... phần xử lý trừ reserve / kho như đã bàn ở trên ...
//
//    Order savedOrder = orderRepository.save(order);
//
//    // Xóa mã giảm giá khỏi session sau khi đặt hàng thành công
//    // session.removeAttribute("appliedCouponCode");
//
//    return savedOrder;
//}
}