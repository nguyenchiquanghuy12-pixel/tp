package com.example.ttap.service;

import com.example.ttap.entity.OrderStatus;
import com.example.ttap.repository.OItemRepository;
import com.example.ttap.repository.TopSellingProductProjection;
import com.example.ttap.repository.ndre;
import com.example.ttap.repository.orderre;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class AdminDashboardService {
    private final ndre nguoidungRepository; // đổi đúng tên repository của entity nguoidung
    private final orderre orderRepository;
    private final OItemRepository oItemRepository;

    public AdminDashboardService(ndre nguoidungRepository,
                                 orderre orderRepository,
                                 OItemRepository oItemRepository) {
        this.nguoidungRepository = nguoidungRepository;
        this.orderRepository = orderRepository;
        this.oItemRepository = oItemRepository;
    }

    public Map<String, Object> getDashboardSummary(int topLimit) {
        Map<String, Object> stats = new LinkedHashMap<>();

        // 1. Tổng số user
        long totalUsers = nguoidungRepository.count();

        // 2. Tổng số order
        long totalOrders = orderRepository.count();

        // 3. Doanh thu (ví dụ tính trên đơn DELIVERED)
        BigDecimal totalRevenue = orderRepository.sumTotalAmountByStatus(OrderStatus.DELIVERED);

        // 4. Số lượng order theo từng OrderStatus
        Map<OrderStatus, Long> ordersByStatus = new EnumMap<>(OrderStatus.class);
        for (OrderStatus status : OrderStatus.values()) {
            ordersByStatus.put(status, orderRepository.countByStatus(status));
        }

        // 5. Top-selling products (mặc định lấy top 5)
        List<TopSellingProductProjection> topProducts =
                oItemRepository.findTopSellingProducts(PageRequest.of(0, Math.max(1, topLimit)));

        stats.put("totalUsers", totalUsers);
        stats.put("totalOrders", totalOrders);
        stats.put("totalRevenue", totalRevenue);
        stats.put("ordersByStatus", ordersByStatus);
        stats.put("topProducts", topProducts);

        return stats;
    }
}
