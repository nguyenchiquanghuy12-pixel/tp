package com.example.ttap.entity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDateTime;
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "inventory_audit_log")
public class tonkho {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Integer id;
@Column(name = "san_pham_sku")
    private String sanphamSku;
    @Column(name = "loai_thao_tac")
    private String loaiThaoTac;
    @Column(name = "so_Luong_Thay_Doi")
    private Integer soLuongThayDoi;
    @Column(name = "admin_email")
    private String adminEmail;
    @Column(name = "ghi_chu")
    private String ghiChu;
@Column(name = "ngay_thao_tac")
    private LocalDateTime ngayThaoTac;
}
