package com.example.ttap.repository;
import com.example.ttap.entity.nguoidung;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
@Repository
public interface ndre extends JpaRepository<nguoidung, Integer> {
nguoidung findByEmail(String email);
    Integer id(Integer id);
    boolean existsByEmail(String email);
    String email(String email);
    List<nguoidung> findAllByOrderByIdDesc();
}