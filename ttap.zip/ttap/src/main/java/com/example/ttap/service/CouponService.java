package com.example.ttap.service;

import com.example.ttap.entity.Coupon;
import com.example.ttap.entity.CouponStatus;
import com.example.ttap.entity.DiscountType;
import com.example.ttap.repository.CouponRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class CouponService {

    @Autowired
    private CouponRepository couponRepository;

    /**
     * Dùng khi khách nhập mã và bấm "Áp dụng" qua AJAX (Preview số tiền giảm, không khóa, không tăng usedCount)
     */
    public double previewDiscount(String code, double orderSubtotal) {
        Coupon coupon = couponRepository.findByCode(code.trim())
                .orElseThrow(() -> new RuntimeException("Mã giảm giá không tồn tại!"));

        validateCoupon(coupon, orderSubtotal);
        return calculateAmount(coupon, orderSubtotal);
    }

    /**
     * [QUAN TRỌNG] Dùng khi XÁC NHẬN THANH TOÁN ĐƠN HÀNG
     * Có khóa bi quan để chống tranh chấp đồng thời (race condition) khi sắp hết lượt.
     */
    @Transactional(rollbackFor = Exception.class)
    public double applyAndConsumeCoupon(String code, double orderSubtotal) {
        // Khóa dòng dữ liệu coupon trong database
        Coupon coupon = couponRepository.findByCodeWithLock(code.trim())
                .orElseThrow(() -> new RuntimeException("Mã giảm giá không tồn tại!"));

        // Kiểm tra lại toàn bộ điều kiện
        validateCoupon(coupon, orderSubtotal);

        // Tính số tiền được giảm
        double discountAmount = calculateAmount(coupon, orderSubtotal);

        // Tăng lượt sử dụng lên 1 ngay lập tức trong transaction bị khóa
        coupon.setUsedCount(coupon.getUsedCount() + 1);

        // Nếu đã chạm mốc giới hạn, tự động chuyển trạng thái thành EXPIRED
        if (coupon.getUsageLimit() != null && coupon.getUsedCount() >= coupon.getUsageLimit()) {
            coupon.setStatus(CouponStatus.EXPIRED);
        }

        couponRepository.save(coupon);

        return discountAmount;
    }

    // --- Hàm phụ trợ kiểm tra điều kiện chung ---
    private void validateCoupon(Coupon coupon, double orderSubtotal) {
        LocalDateTime now = LocalDateTime.now();

        if (coupon.getStatus() != CouponStatus.ACTIVE) {
            throw new RuntimeException("Mã giảm giá này hiện không hoạt động.");
        }
        if (coupon.getStartDate() != null && now.isBefore(coupon.getStartDate())) {
            throw new RuntimeException("Mã giảm giá chưa đến thời gian sử dụng.");
        }
        if (coupon.getEndDate() != null && now.isAfter(coupon.getEndDate())) {
            throw new RuntimeException("Mã giảm giá đã hết hạn sử dụng.");
        }
        if (coupon.getUsageLimit() != null && coupon.getUsedCount() >= coupon.getUsageLimit()) {
            throw new RuntimeException("Mã giảm giá đã hết lượt sử dụng.");
        }
        if (coupon.getMinOrderValue() != null && orderSubtotal < coupon.getMinOrderValue()) {
            throw new RuntimeException("Đơn hàng chưa đạt giá trị tối thiểu (Tối thiểu: " + coupon.getMinOrderValue() + " đ).");
        }
    }

    // --- Hàm phụ trợ tính toán số tiền giảm ---
    private double calculateAmount(Coupon coupon, double orderSubtotal) {
        double discountAmount = 0.0;
        if (coupon.getDiscountType() == DiscountType.FIXED) {
            discountAmount = coupon.getDiscountValue();
        } else if (coupon.getDiscountType() == DiscountType.PERCENTAGE) {
            discountAmount = orderSubtotal * (coupon.getDiscountValue() / 100.0);
            if (coupon.getMaxDiscountAmount() != null && discountAmount > coupon.getMaxDiscountAmount()) {
                discountAmount = coupon.getMaxDiscountAmount();
            }
        }
        return Math.min(discountAmount, orderSubtotal);
    }
    public double calculateDiscount(String couponCode, double subtotal) {
        if (couponCode == null || couponCode.trim().isEmpty()) {
            return 0.0;
        }

        // Tìm mã giảm giá trong database
        Coupon coupon = couponRepository.findByCode(couponCode.trim()).orElse(null);

        if (coupon == null) {
            return 0.0; // Mã không tồn tại
        }

        double discountAmount = 0.0;

        // Lấy giá trị giảm và kiểu giảm giá (DiscountType là Enum)
        DiscountType type = coupon.getDiscountType();
        double value = coupon.getDiscountValue(); // Ví dụ: 10 (cho 10%) hoặc 50000 (cho 50k)

        // So sánh trực tiếp với các giá trị của Enum DiscountType
        // (Giả tên các hằng số trong Enum của bạn là PERCENTAGE và FIXED, nếu khác bạn chỉnh lại tên cho khớp)
        if (DiscountType.PERCENTAGE.equals(type)) {
            discountAmount = subtotal * (value / 100.0);
        } else if (DiscountType.FIXED.equals(type)) {
            discountAmount = value;
        } else {
            discountAmount = value;
        }

        // Đảm bảo số tiền giảm giá không vượt quá tổng tiền hàng tạm tính
        return Math.min(discountAmount, subtotal);
    }
}